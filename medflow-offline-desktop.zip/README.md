# MedFlow Clinic Manager (Offline Desktop)

Data is stored in a local SQLite file (`%APPDATA%\MedFlow Clinic\medflow.db`).
No internet is needed. Automatic daily backups go to `Documents\MedFlow Backups`.

## Build the Windows installer
- GitHub: upload this folder, open Actions > "Build Windows EXE" > Run workflow, download the artifact.
- Or on a PC with Node.js 22: `npm install` then `npm run dist:win` (installer appears in `release/`).

## Run for testing
`npm install` then `npm start`
