/**
 * Local replacement for `firebase/firestore`.
 *
 * Same function names (collection, doc, getDoc, getDocs, setDoc, updateDoc,
 * deleteDoc, query, where, orderBy, limit, onSnapshot) so the rest of the app
 * keeps working unchanged. Data lives in an in-memory cache that is loaded
 * once at startup and written through to SQLite (Electron) on every change.
 * When running in a normal browser (npm run dev) it falls back to localStorage.
 */

type Json = Record<string, any>;

interface ElectronAPI {
  dbLoadAll(): Promise<[string, string, string][]>;
  dbSet(col: string, id: string, json: string): Promise<boolean>;
  dbDelete(col: string, id: string): Promise<boolean>;
  getDbInfo(): Promise<{ dbPath: string; backupDir: string }>;
  exportBackup(): Promise<{ ok: boolean; path?: string; error?: string; canceled?: boolean }>;
  restoreBackup(): Promise<{ ok: boolean; error?: string; canceled?: boolean }>;
  openBackupFolder(): Promise<boolean>;
}

declare global {
  interface Window {
    electronAPI?: ElectronAPI;
  }
}

const BROWSER_KEY = 'medflow_local_db_v1';

const cache = new Map<string, Map<string, Json>>();
const listeners = new Map<string, Set<() => void>>();
const pending = new Set<string>();

const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));

function colMap(name: string): Map<string, Json> {
  let m = cache.get(name);
  if (!m) {
    m = new Map();
    cache.set(name, m);
  }
  return m;
}

// ---------- persistence ----------
function persistBrowser() {
  try {
    const out: Record<string, Json[]> = {};
    cache.forEach((m, c) => (out[c] = Array.from(m.entries()).map(([id, d]) => ({ __id: id, ...d }))));
    localStorage.setItem(BROWSER_KEY, JSON.stringify(out));
  } catch (e) {
    console.error('Browser persist failed', e);
  }
}

export async function initStore(): Promise<void> {
  cache.clear();
  if (window.electronAPI) {
    const rows = await window.electronAPI.dbLoadAll();
    for (const [col, id, json] of rows) colMap(col).set(id, JSON.parse(json));
  } else {
    try {
      const raw = localStorage.getItem(BROWSER_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Record<string, Json[]>;
        for (const [col, list] of Object.entries(parsed)) {
          for (const item of list) {
            const { __id, ...rest } = item;
            colMap(col).set(__id, rest);
          }
        }
      }
    } catch (e) {
      console.error('Browser load failed', e);
    }
  }
}

async function persistSet(col: string, id: string, data: Json) {
  if (window.electronAPI) {
    await window.electronAPI.dbSet(col, id, JSON.stringify(data));
  }
}
async function persistDelete(col: string, id: string) {
  if (window.electronAPI) {
    await window.electronAPI.dbDelete(col, id);
  }
}

function notify(col: string) {
  const set = listeners.get(col);
  if (!set || set.size === 0 || pending.has(col)) return;
  pending.add(col);
  queueMicrotask(() => {
    pending.delete(col);
    Array.from(listeners.get(col) ?? []).forEach((fn) => fn());
  });
}

// ---------- references ----------
export const db = {};
export interface CollectionRef { type: 'collection'; name: string }
export interface DocRef { type: 'doc'; col: string; id: string }
type Constraint =
  | { t: 'where'; f: string; op: string; v: any }
  | { t: 'order'; f: string; dir: 'asc' | 'desc' }
  | { t: 'limit'; n: number };
export interface QueryRef { type: 'query'; col: string; constraints: Constraint[] }

export function collection(_db: unknown, name: string): CollectionRef {
  return { type: 'collection', name };
}
export function doc(_db: unknown, col: string, id: string): DocRef {
  return { type: 'doc', col, id };
}
export function where(f: string, op: string, v: any): Constraint {
  return { t: 'where', f, op, v };
}
export function orderBy(f: string, dir: 'asc' | 'desc' = 'asc'): Constraint {
  return { t: 'order', f, dir };
}
export function limit(n: number): Constraint {
  return { t: 'limit', n };
}
export function query(ref: CollectionRef | QueryRef, ...constraints: Constraint[]): QueryRef {
  if (ref.type === 'collection') return { type: 'query', col: ref.name, constraints };
  return { type: 'query', col: ref.col, constraints: [...ref.constraints, ...constraints] };
}

// ---------- query engine ----------
function cmp(a: any, b: any): number {
  if (a === b) return 0;
  if (a === undefined || a === null) return -1;
  if (b === undefined || b === null) return 1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a) < String(b) ? -1 : 1;
}

function matches(value: any, op: string, target: any): boolean {
  switch (op) {
    case '==': return value === target;
    case '!=': return value !== target;
    case '<': return value !== undefined && value !== null && cmp(value, target) < 0;
    case '<=': return value !== undefined && value !== null && cmp(value, target) <= 0;
    case '>': return value !== undefined && value !== null && cmp(value, target) > 0;
    case '>=': return value !== undefined && value !== null && cmp(value, target) >= 0;
    case 'in': return Array.isArray(target) && target.includes(value);
    case 'not-in': return Array.isArray(target) && !target.includes(value);
    case 'array-contains': return Array.isArray(value) && value.includes(target);
    default: throw new Error('Unsupported where operator: ' + op);
  }
}

function run(q: QueryRef): { id: string; data: Json }[] {
  let rows = Array.from(colMap(q.col).entries()).map(([id, data]) => ({ id, data }));
  for (const c of q.constraints) {
    if (c.t === 'where') rows = rows.filter((r) => matches(r.data[c.f], c.op, c.v));
  }
  const orders = q.constraints.filter((c): c is Extract<Constraint, { t: 'order' }> => c.t === 'order');
  if (orders.length) {
    // Firestore leaves out documents that do not have the ordered field
    rows = rows.filter((r) => orders.every((o) => r.data[o.f] !== undefined && r.data[o.f] !== null));
    rows.sort((a, b) => {
      for (const o of orders) {
        const r = cmp(a.data[o.f], b.data[o.f]);
        if (r !== 0) return o.dir === 'desc' ? -r : r;
      }
      return 0;
    });
  }
  const lim = q.constraints.find((c): c is Extract<Constraint, { t: 'limit' }> => c.t === 'limit');
  if (lim) rows = rows.slice(0, lim.n);
  return rows;
}

// ---------- snapshots ----------
export interface DocSnap {
  id: string;
  exists(): boolean;
  data(): any;
}
export interface QuerySnap {
  docs: DocSnap[];
  empty: boolean;
  size: number;
  forEach(fn: (d: DocSnap) => void): void;
}

const mkDoc = (id: string, data: Json | undefined): DocSnap => ({
  id,
  exists: () => data !== undefined,
  data: () => (data === undefined ? undefined : clone(data)),
});

function mkSnap(rows: { id: string; data: Json }[]): QuerySnap {
  const docs = rows.map((r) => mkDoc(r.id, r.data));
  return { docs, empty: docs.length === 0, size: docs.length, forEach: (fn) => docs.forEach(fn) };
}

// ---------- reads ----------
export async function getDoc(ref: DocRef): Promise<DocSnap> {
  return mkDoc(ref.id, colMap(ref.col).get(ref.id));
}

export async function getDocs(ref: CollectionRef | QueryRef): Promise<QuerySnap> {
  const q = ref.type === 'collection' ? query(ref) : ref;
  return mkSnap(run(q));
}

// ---------- writes ----------
export async function setDoc(ref: DocRef, data: Json): Promise<void> {
  const copy = clone(data);
  await persistSet(ref.col, ref.id, copy);
  colMap(ref.col).set(ref.id, copy);
  if (!window.electronAPI) persistBrowser();
  notify(ref.col);
}

export async function updateDoc(ref: DocRef, updates: Json): Promise<void> {
  const existing = colMap(ref.col).get(ref.id);
  if (!existing) throw new Error(`No document to update: ${ref.col}/${ref.id}`);
  const merged = { ...existing, ...clone(updates) };
  await persistSet(ref.col, ref.id, merged);
  colMap(ref.col).set(ref.id, merged);
  if (!window.electronAPI) persistBrowser();
  notify(ref.col);
}

export async function deleteDoc(ref: DocRef): Promise<void> {
  await persistDelete(ref.col, ref.id);
  colMap(ref.col).delete(ref.id);
  if (!window.electronAPI) persistBrowser();
  notify(ref.col);
}

// ---------- realtime ----------
export function onSnapshot(
  ref: CollectionRef | QueryRef,
  next: (snap: QuerySnap) => void,
  error?: (err: Error) => void
): () => void {
  const q = ref.type === 'collection' ? query(ref) : ref;
  const fire = () => {
    try {
      next(mkSnap(run(q)));
    } catch (e) {
      if (error) error(e as Error);
      else console.error(e);
    }
  };
  let set = listeners.get(q.col);
  if (!set) {
    set = new Set();
    listeners.set(q.col, set);
  }
  set.add(fire);
  setTimeout(fire, 0);
  return () => {
    listeners.get(q.col)?.delete(fire);
  };
}
