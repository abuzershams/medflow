# MedFlow Clinic Manager (Offline Desktop)

Data is stored in a local SQLite file (`%APPDATA%\MedFlow Clinic\medflow.db`).
No internet is needed. Automatic daily backups go to `Documents\MedFlow Backups`.

## Build the Windows installer
- GitHub: upload this folder, open Actions > "Build Windows EXE" > Run workflow, download the artifact.
- Or on a PC with Node.js 22: `npm install` then `npm run dist:win` (installer appears in `release/`).

## Run for testing
`npm install` then `npm start`


## Build Android APK with GitHub Actions
1. Upload/push this project folder to a GitHub repository (include the `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or push to `main`/`master`).
4. When the workflow finishes, open its run and download the **MedFlow-Android-APK** artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

## Important
- The Windows installer is built by the existing **Build Windows EXE** workflow. Download its `MedFlow-Windows-Installer` artifact from the Actions run.
- The Android APK is a mobile wrapper around the existing web interface. Electron-only desktop features (SQLite database, Windows file/folder backup dialogs) are not available on Android; the current browser fallback stores data in that app's local web storage. Do not assume Windows and Android data automatically sync between devices.
- This workflow produces a debug APK for testing, not a Play Store-signed release.
