import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.medflow.clinic',
  appName: 'MedFlow Clinic',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
