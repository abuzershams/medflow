import React, { useState } from 'react';
import {
  Patient,
  Appointment,
  Vital,
  Consultation,
  Prescription,
  Invoice,
  Payment,
  MedicalDocument,
  FollowUp,
} from '../../types';
import { WhatsAppButton } from '../common/WhatsAppButton';
import {
  X,
  User,
  Phone,
  MapPin,
  Calendar,
  Activity,
  Stethoscope,
  FileText,
  Receipt,
  FolderArchive,
  CalendarClock,
  Clock,
  Droplet,
  Plus,
  Printer,
  FileCheck,
} from 'lucide-react';

interface PatientProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: Patient | null;
  appointments: Appointment[];
  vitals: Vital[];
  consultations: Consultation[];
  prescriptions: Prescription[];
  invoices: Invoice[];
  payments: Payment[];
  documents: MedicalDocument[];
  followUps: FollowUp[];
  onOpenConsultation: (patient: Patient) => void;
  onOpenPrescriptionPrint: (rx: Prescription) => void;
  onOpenInvoicePrint: (inv: Invoice) => void;
}

export const PatientProfileModal: React.FC<PatientProfileModalProps> = ({
  isOpen,
  onClose,
  patient,
  appointments,
  vitals,
  consultations,
  prescriptions,
  invoices,
  payments,
  documents,
  followUps,
  onOpenConsultation,
  onOpenPrescriptionPrint,
  onOpenInvoicePrint,
}) => {
  const [activeTab, setActiveTab] = useState<
    'timeline' | 'overview' | 'appointments' | 'vitals' | 'consultations' | 'prescriptions' | 'billing' | 'documents' | 'followups'
  >('timeline');

  if (!isOpen || !patient) return null;

  // Filter records belonging to this patient
  const pAppointments = appointments.filter((a) => a.patientId === patient.id || a.patientName === patient.fullName);
  const pVitals = vitals.filter((v) => v.patientId === patient.id);
  const pConsultations = consultations.filter((c) => c.patientId === patient.id);
  const pPrescriptions = prescriptions.filter((rx) => rx.patientId === patient.id);
  const pInvoices = invoices.filter((i) => i.patientId === patient.id);
  const pPayments = payments.filter((p) => p.patientId === patient.id);
  const pDocuments = documents.filter((d) => d.patientId === patient.id);
  const pFollowUps = followUps.filter((f) => f.patientId === patient.id);

  // Compile unified chronological timeline
  interface TimelineEvent {
    id: string;
    date: string;
    type: 'appointment' | 'vital' | 'consultation' | 'prescription' | 'invoice' | 'payment' | 'followup' | 'document';
    title: string;
    subtitle: string;
    statusBadge?: string;
    rawItem: any;
  }

  const timelineEvents: TimelineEvent[] = [
    ...pAppointments.map((a) => ({
      id: `apt-${a.id}`,
      date: a.date,
      type: 'appointment' as const,
      title: `Appointment: ${a.type.toUpperCase()}`,
      subtitle: `Status: ${a.status.replace('_', ' ')} • Reason: ${a.reason}`,
      statusBadge: a.status,
      rawItem: a,
    })),
    ...pVitals.map((v) => ({
      id: `vit-${v.id}`,
      date: v.recordedAt.split('T')[0] || v.createdAt.split('T')[0],
      type: 'vital' as const,
      title: `Vitals Recorded by ${v.recordedBy}`,
      subtitle: `BP: ${v.bpSystolic || '-'}/${v.bpDiastolic || '-'} mmHg • Pulse: ${v.pulse || '-'} bpm • Temp: ${v.temperature || '-'}°F • BMI: ${v.bmi || '-'}`,
      rawItem: v,
    })),
    ...pConsultations.map((c) => ({
      id: `con-${c.id}`,
      date: c.createdAt.split('T')[0],
      type: 'consultation' as const,
      title: `Doctor Consultation (${c.doctorName})`,
      subtitle: `Diagnosis: ${c.diagnosis} • Complaint: ${c.chiefComplaint}`,
      rawItem: c,
    })),
    ...pPrescriptions.map((rx) => ({
      id: `rx-${rx.id}`,
      date: rx.createdAt.split('T')[0],
      type: 'prescription' as const,
      title: `Digital Prescription ${rx.prescriptionNumber}`,
      subtitle: `${rx.medicines.length} medicines prescribed for ${rx.diagnosis}`,
      rawItem: rx,
    })),
    ...pInvoices.map((inv) => ({
      id: `inv-${inv.id}`,
      date: inv.date || inv.createdAt.split('T')[0],
      type: 'invoice' as const,
      title: `Invoice Generated (${inv.invoiceNumber})`,
      subtitle: `Total: $${inv.total.toFixed(2)} • Paid: $${inv.paidAmount.toFixed(2)} • Due: $${inv.dueAmount.toFixed(2)}`,
      statusBadge: inv.status,
      rawItem: inv,
    })),
    ...pPayments.map((pay) => ({
      id: `pay-${pay.id}`,
      date: pay.date || pay.createdAt.split('T')[0],
      type: 'payment' as const,
      title: `Payment Received: $${pay.amount.toFixed(2)}`,
      subtitle: `Mode: ${pay.method.toUpperCase()} • Receipt Ref: ${pay.referenceNumber || pay.invoiceNumber}`,
      rawItem: pay,
    })),
    ...pFollowUps.map((flw) => ({
      id: `flw-${flw.id}`,
      date: flw.scheduledDate,
      type: 'followup' as const,
      title: `Scheduled Follow-up Consultation`,
      subtitle: `Reason: ${flw.reason} • Status: ${flw.status}`,
      statusBadge: flw.status,
      rawItem: flw,
    })),
    ...pDocuments.map((doc) => ({
      id: `doc-${doc.id}`,
      date: doc.createdAt.split('T')[0],
      type: 'document' as const,
      title: `Document Uploaded: ${doc.title}`,
      subtitle: `Type: ${doc.documentType.replace('_', ' ').toUpperCase()}`,
      rawItem: doc,
    })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const totalBilled = pInvoices.reduce((sum, inv) => sum + inv.total, 0);
  const totalPaid = pInvoices.reduce((sum, inv) => sum + inv.paidAmount, 0);
  const totalDue = pInvoices.reduce((sum, inv) => sum + inv.dueAmount, 0);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header Profile Bar */}
        <div className="bg-slate-900 text-white p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-500 text-white font-extrabold text-xl flex items-center justify-center shadow-md">
              {patient.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-lg font-bold text-white tracking-tight">{patient.fullName}</h2>
                <span className="px-2 py-0.5 rounded-md bg-blue-500/20 text-cyan-300 font-mono text-xs font-semibold border border-blue-500/30">
                  {patient.patientId}
                </span>
                <span className="px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-500/30 flex items-center gap-1">
                  <Droplet className="w-3 h-3" />
                  {patient.bloodGroup || 'N/A'}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300 mt-1">
                <span>{patient.age} Yrs • {patient.gender}</span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  {patient.phone}
                </span>
                {patient.city && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {patient.city}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center">
            <WhatsAppButton
              phone={patient.phone}
              patientName={patient.fullName}
              messageType="general"
              size="md"
            />
            <button
              onClick={() => {
                onOpenConsultation(patient);
                onClose();
              }}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition"
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>Start Consultation</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-200 bg-slate-50 px-4 overflow-x-auto scrollbar-none text-xs font-semibold">
          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-3.5 py-3 border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'timeline'
                ? 'border-blue-600 text-blue-600 bg-white font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Timeline Feed ({timelineEvents.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-3 border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'overview'
                ? 'border-blue-600 text-blue-600 bg-white font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Overview & Notes</span>
          </button>
          <button
            onClick={() => setActiveTab('vitals')}
            className={`px-3.5 py-3 border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'vitals'
                ? 'border-blue-600 text-blue-600 bg-white font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Vitals ({pVitals.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('consultations')}
            className={`px-3.5 py-3 border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'consultations'
                ? 'border-blue-600 text-blue-600 bg-white font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Stethoscope className="w-4 h-4" />
            <span>Consultations ({pConsultations.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('prescriptions')}
            className={`px-3.5 py-3 border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'prescriptions'
                ? 'border-blue-600 text-blue-600 bg-white font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Prescriptions ({pPrescriptions.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('billing')}
            className={`px-3.5 py-3 border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'billing'
                ? 'border-blue-600 text-blue-600 bg-white font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Billing & Payments (${totalDue > 0 ? `Due: $${totalDue.toFixed(0)}` : 'Clear'})</span>
          </button>
          <button
            onClick={() => setActiveTab('documents')}
            className={`px-3.5 py-3 border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              activeTab === 'documents'
                ? 'border-blue-600 text-blue-600 bg-white font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FolderArchive className="w-4 h-4" />
            <span>Documents ({pDocuments.length})</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 bg-white">
          
          {/* TAB 1: UNIFIED CHRONOLOGICAL TIMELINE */}
          {activeTab === 'timeline' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Chronological Medical History</h4>
                  <p className="text-xs text-slate-500">
                    Unified timeline of all encounters, prescriptions, vitals, invoices, and follow-ups.
                  </p>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700">
                  {timelineEvents.length} Recorded Milestones
                </span>
              </div>

              {timelineEvents.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No chronological medical events recorded for this patient yet.
                </div>
              ) : (
                <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                  {timelineEvents.map((evt) => {
                    const badgeStyles: Record<string, string> = {
                      appointment: 'bg-indigo-500 ring-indigo-200',
                      vital: 'bg-emerald-500 ring-emerald-200',
                      consultation: 'bg-blue-600 ring-blue-200',
                      prescription: 'bg-cyan-500 ring-cyan-200',
                      invoice: 'bg-amber-500 ring-amber-200',
                      payment: 'bg-teal-500 ring-teal-200',
                      followup: 'bg-purple-500 ring-purple-200',
                      document: 'bg-rose-500 ring-rose-200',
                    };

                    return (
                      <div key={evt.id} className="relative group">
                        {/* Dot marker */}
                        <div
                          className={`absolute -left-[27px] top-1.5 w-3.5 h-3.5 rounded-full border-2 border-white ring-4 ${
                            badgeStyles[evt.type] || 'bg-slate-400 ring-slate-100'
                          }`}
                        />

                        <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-slate-300 transition shadow-2xs">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="font-bold text-xs text-slate-900">{evt.title}</span>
                            <span className="text-[11px] font-mono text-slate-500 font-semibold">{evt.date}</span>
                          </div>
                          <p className="text-xs text-slate-600">{evt.subtitle}</p>

                          {/* Quick Actions depending on type */}
                          {evt.type === 'prescription' && (
                            <div className="mt-2 pt-2 border-t border-slate-200/60 flex justify-end">
                              <button
                                onClick={() => onOpenPrescriptionPrint(evt.rawItem)}
                                className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
                              >
                                <Printer className="w-3.5 h-3.5" />
                                <span>Print Prescription</span>
                              </button>
                            </div>
                          )}

                          {evt.type === 'invoice' && (
                            <div className="mt-2 pt-2 border-t border-slate-200/60 flex justify-end">
                              <button
                                onClick={() => onOpenInvoicePrint(evt.rawItem)}
                                className="text-xs font-semibold text-amber-600 hover:text-amber-800 flex items-center gap-1"
                              >
                                <Receipt className="w-3.5 h-3.5" />
                                <span>View Invoice</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                  <h4 className="font-bold text-slate-900 text-sm mb-2">Demographics & Details</h4>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-500">Patient ID</span>
                    <span className="font-semibold text-slate-800">{patient.patientId}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-500">Gender & Age</span>
                    <span className="font-semibold text-slate-800">{patient.gender}, {patient.age} Years</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-500">Blood Group</span>
                    <span className="font-semibold text-rose-700">{patient.bloodGroup || 'Unknown'}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-500">Primary Mobile</span>
                    <span className="font-semibold text-slate-800">{patient.phone}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span className="text-slate-500">Alternate Phone</span>
                    <span className="font-semibold text-slate-800">{patient.alternatePhone || 'None'}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Emergency Contact</span>
                    <span className="font-semibold text-slate-800">{patient.emergencyContact || 'Not provided'}</span>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                  <h4 className="font-bold text-slate-900 text-sm mb-2">Address & Clinical Notes</h4>
                  <div className="mb-3">
                    <span className="text-slate-500 block mb-1">Residential Address:</span>
                    <p className="font-medium text-slate-800 bg-white p-2.5 rounded-lg border border-slate-200">
                      {patient.address || 'Address not provided'} {patient.city ? `• ${patient.city}` : ''}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-1">Allergies / Clinical Notes:</span>
                    <p className="font-medium text-slate-800 bg-white p-2.5 rounded-lg border border-slate-200">
                      {patient.notes || 'No allergies or special conditions recorded.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: VITALS */}
          {activeTab === 'vitals' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">Recorded Vitals History</h4>
                <span className="text-xs text-slate-500">{pVitals.length} records</span>
              </div>

              {pVitals.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  No vitals recorded for this patient yet.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 text-slate-600 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="p-2.5">Date</th>
                        <th className="p-2.5">BP (mmHg)</th>
                        <th className="p-2.5">Pulse (bpm)</th>
                        <th className="p-2.5">SpO2</th>
                        <th className="p-2.5">Weight / Height</th>
                        <th className="p-2.5">BMI</th>
                        <th className="p-2.5">Staff</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {pVitals.map((v) => (
                        <tr key={v.id} className="hover:bg-slate-50">
                          <td className="p-2.5 font-semibold text-slate-900">{v.recordedAt.split('T')[0]}</td>
                          <td className="p-2.5 font-mono">
                            {v.bpSystolic && v.bpDiastolic ? `${v.bpSystolic}/${v.bpDiastolic}` : '-'}
                          </td>
                          <td className="p-2.5 font-mono">{v.pulse ? `${v.pulse}` : '-'}</td>
                          <td className="p-2.5 font-mono">{v.spo2 ? `${v.spo2}%` : '-'}</td>
                          <td className="p-2.5">{v.weight ? `${v.weight} kg` : '-'} / {v.height ? `${v.height} cm` : '-'}</td>
                          <td className="p-2.5 font-semibold text-blue-700">{v.bmi || '-'}</td>
                          <td className="p-2.5 text-slate-500">{v.recordedBy}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CONSULTATIONS */}
          {activeTab === 'consultations' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">Doctor Consultation Notes</h4>
                <button
                  onClick={() => {
                    onOpenConsultation(patient);
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ New Consultation</span>
                </button>
              </div>

              {pConsultations.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  No consultation records for this patient yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {pConsultations.map((c) => (
                    <div key={c.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-sm">{c.diagnosis}</span>
                        <span className="text-slate-500 font-mono">{c.createdAt.split('T')[0]}</span>
                      </div>
                      <p className="text-slate-600"><strong>Chief Complaint:</strong> {c.chiefComplaint}</p>
                      {c.symptoms && <p className="text-slate-600"><strong>Symptoms:</strong> {c.symptoms}</p>}
                      {c.treatmentPlan && <p className="text-slate-600"><strong>Treatment Plan:</strong> {c.treatmentPlan}</p>}
                      {c.advice && <p className="text-slate-600"><strong>Doctor Advice:</strong> {c.advice}</p>}
                      <div className="pt-2 text-[11px] text-slate-400 flex justify-between">
                        <span>Attending: {c.doctorName}</span>
                        {c.followUpDate && <span className="text-blue-600 font-semibold">Follow-up: {c.followUpDate}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: PRESCRIPTIONS */}
          {activeTab === 'prescriptions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">Prescriptions Issued</h4>
                <span className="text-xs text-slate-500">{pPrescriptions.length} records</span>
              </div>

              {pPrescriptions.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  No prescriptions issued for this patient yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {pPrescriptions.map((rx) => (
                    <div key={rx.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-4 text-xs">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-blue-700 text-sm">{rx.prescriptionNumber}</span>
                          <span className="text-slate-400">• {rx.createdAt.split('T')[0]}</span>
                        </div>
                        <p className="text-slate-700 font-semibold">Diagnosis: {rx.diagnosis}</p>
                        <p className="text-slate-500 mt-1">
                          Medicines ({rx.medicines.length}): {rx.medicines.map((m) => m.name).join(', ')}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <WhatsAppButton
                          phone={patient.phone}
                          patientName={patient.fullName}
                          messageType="prescription"
                          size="sm"
                        />
                        <button
                          onClick={() => onOpenPrescriptionPrint(rx)}
                          className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center gap-1.5 shadow-xs"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Print Rx</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: BILLING & PAYMENTS */}
          {activeTab === 'billing' && (
            <div className="space-y-4">
              {/* Summary Financial Bar */}
              <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200 text-center text-xs">
                <div>
                  <span className="text-slate-500">Total Billed</span>
                  <p className="text-base font-extrabold text-slate-900">${totalBilled.toFixed(2)}</p>
                </div>
                <div>
                  <span className="text-slate-500">Total Paid</span>
                  <p className="text-base font-extrabold text-emerald-600">${totalPaid.toFixed(2)}</p>
                </div>
                <div>
                  <span className="text-slate-500">Total Dues</span>
                  <p className="text-base font-extrabold text-rose-600">${totalDue.toFixed(2)}</p>
                </div>
              </div>

              {pInvoices.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  No billing invoices recorded for this patient yet.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {pInvoices.map((inv) => (
                    <div key={inv.id} className="p-3.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{inv.invoiceNumber}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase ${
                            inv.status === 'paid' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                          }`}>
                            {inv.status}
                          </span>
                        </div>
                        <p className="text-slate-500 mt-0.5">Date: {inv.date} • {inv.items.length} line items</p>
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="text-right mr-1">
                          <span className="font-extrabold text-slate-900">${inv.total.toFixed(2)}</span>
                          {inv.dueAmount > 0 ? (
                            <p className="text-[10px] text-rose-600 font-semibold">Due: ${inv.dueAmount.toFixed(2)}</p>
                          ) : (
                            <p className="text-[10px] text-emerald-600 font-semibold">Fully Paid</p>
                          )}
                        </div>
                        {patient.phone && (
                          <WhatsAppButton
                            phone={patient.phone}
                            patientName={patient.fullName}
                            customText={`Hello ${patient.fullName},\n\nYour invoice from clinic:\nInvoice: ${inv.invoiceNumber}\nTotal: $${inv.total.toFixed(2)}\nPaid: $${inv.paidAmount.toFixed(2)}\nDue: $${inv.dueAmount.toFixed(2)}\nStatus: ${inv.status.toUpperCase()}\n\nThank you.`}
                            size="sm"
                          />
                        )}
                        <button
                          onClick={() => onOpenInvoicePrint(inv)}
                          className="px-2.5 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold flex items-center gap-1 cursor-pointer transition"
                          title="Print or Save Invoice PDF"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Invoice</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: DOCUMENTS */}
          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">Lab & Medical Documents</h4>
                <span className="text-xs text-slate-500">{pDocuments.length} files</span>
              </div>

              {pDocuments.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  No medical reports or scans uploaded for this patient.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {pDocuments.map((doc) => (
                    <div key={doc.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex items-start gap-3 text-xs">
                      <FileCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                      <div className="flex-1 overflow-hidden">
                        <p className="font-bold text-slate-900 truncate">{doc.title}</p>
                        <p className="text-[11px] text-slate-500 uppercase">{doc.documentType.replace('_', ' ')}</p>
                        {doc.notes && <p className="text-[11px] text-slate-600 mt-1 italic">{doc.notes}</p>}
                        <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                          <span>{doc.createdAt.split('T')[0]}</span>
                          {doc.fileUrl && (
                            <a
                              href={doc.fileUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-blue-600 font-semibold hover:underline"
                            >
                              Download / View
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
