import React from 'react';
import { AlertTriangle, Trash2, X, Loader2, ShieldAlert } from 'lucide-react';
import { Patient } from '../../types';

interface DeletePatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: Patient | null;
  onConfirmDelete: (patient: Patient) => Promise<void>;
  isDeleting: boolean;
  errorMessage?: string | null;
  clinicalHistoryCount?: number;
}

export const DeletePatientModal: React.FC<DeletePatientModalProps> = ({
  isOpen,
  onClose,
  patient,
  onConfirmDelete,
  isDeleting,
  errorMessage,
  clinicalHistoryCount = 0,
}) => {
  if (!isOpen || !patient) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150"
        role="dialog"
        aria-modal="true"
        aria-labelledby="delete-patient-title"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-start justify-between bg-slate-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0 border border-rose-200 shadow-2xs">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 id="delete-patient-title" className="text-base font-bold text-slate-900">
                Delete Patient?
              </h3>
              <p className="text-xs text-slate-500">
                Remove patient from active registry
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isDeleting}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition disabled:opacity-50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-xs">
          {/* Patient Details Card */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-slate-500 text-[11px] font-semibold uppercase">Patient Name</span>
              <span className="font-bold text-slate-900 text-sm">{patient.fullName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500 text-[11px] font-semibold uppercase">Patient ID</span>
              <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                {patient.patientId}
              </span>
            </div>
            <div className="flex justify-between items-center text-slate-600">
              <span className="text-slate-500 text-[11px] font-semibold uppercase">Phone / Age</span>
              <span>{patient.phone} • {patient.age} Yrs ({patient.gender})</span>
            </div>
          </div>

          {/* Medical Record Safety Warning */}
          {clinicalHistoryCount > 0 ? (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-xs text-amber-800">
                <ShieldAlert className="w-4 h-4 shrink-0 text-amber-600" />
                <span>Medical Record Safety Protected</span>
              </div>
              <p className="text-[11px] leading-relaxed text-amber-800">
                This patient has <span className="font-bold">{clinicalHistoryCount} clinical record(s)</span> (consultations, vitals, prescriptions, or visits). To prevent accidental loss of important clinical history, deleting will securely archive this patient while safeguarding their prior medical logs.
              </p>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-600 space-y-1">
              <p className="leading-relaxed">
                Are you sure you want to delete this patient record? This action will permanently remove the record from the database.
              </p>
            </div>
          )}

          {/* Error Message if Deletion Failed */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <div>
                <p className="font-bold">Deletion Failed</p>
                <p className="text-[11px] mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs transition disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onConfirmDelete(patient)}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition shadow-xs flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
          >
            {isDeleting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Deleting...</span>
              </>
            ) : (
              <>
                <Trash2 className="w-4 h-4" />
                <span>Delete Patient</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
