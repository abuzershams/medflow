import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { LogoutConfirmationModal } from '../common/LogoutConfirmationModal';
import {
  LayoutDashboard,
  Users,
  Calendar,
  Stethoscope,
  Activity,
  FileText,
  Pill,
  Package,
  Truck,
  Receipt,
  CreditCard,
  FolderArchive,
  CalendarClock,
  BarChart3,
  UserCog,
  Settings,
  X,
  HeartPulse,
  LogOut,
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpenMobile,
  onCloseMobile,
}) => {
  const { currentUser, clinic } = useAuth();
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const role = currentUser?.role || 'staff';

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      roles: ['admin', 'doctor', 'receptionist', 'nurse', 'pharmacy', 'staff'],
    },
    {
      id: 'patients',
      label: 'Patients',
      icon: Users,
      roles: ['admin', 'doctor', 'receptionist', 'nurse', 'staff'],
    },
    {
      id: 'appointments',
      label: 'Appointments',
      icon: Calendar,
      roles: ['admin', 'doctor', 'receptionist', 'nurse', 'staff'],
    },
    {
      id: 'consultation',
      label: 'OPD / Consultation',
      icon: Stethoscope,
      roles: ['admin', 'doctor'],
    },
    {
      id: 'vitals',
      label: 'Vitals Recording',
      icon: Activity,
      roles: ['admin', 'doctor', 'receptionist', 'nurse'],
    },
    {
      id: 'prescriptions',
      label: 'Prescriptions',
      icon: FileText,
      roles: ['admin', 'doctor'],
    },
    {
      id: 'medicines',
      label: 'Medicines Master',
      icon: Pill,
      roles: ['admin', 'doctor', 'pharmacy'],
    },
    {
      id: 'inventory',
      label: 'Stock / Inventory',
      icon: Package,
      roles: ['admin', 'pharmacy'],
    },
    {
      id: 'suppliers',
      label: 'Suppliers',
      icon: Truck,
      roles: ['admin', 'pharmacy'],
    },
    {
      id: 'billing',
      label: 'Billing & Invoices',
      icon: Receipt,
      roles: ['admin', 'doctor', 'receptionist', 'pharmacy'],
    },
    {
      id: 'payments',
      label: 'Payments Log',
      icon: CreditCard,
      roles: ['admin', 'doctor', 'receptionist', 'pharmacy'],
    },
    {
      id: 'documents',
      label: 'Medical Documents',
      icon: FolderArchive,
      roles: ['admin', 'doctor', 'nurse'],
    },
    {
      id: 'followups',
      label: 'Follow-ups',
      icon: CalendarClock,
      roles: ['admin', 'doctor', 'receptionist'],
    },
    {
      id: 'reports',
      label: 'Reports & Analytics',
      icon: BarChart3,
      roles: ['admin', 'doctor'],
    },
    {
      id: 'staff',
      label: 'Staff Management',
      icon: UserCog,
      roles: ['admin'],
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      roles: ['admin', 'doctor', 'receptionist', 'nurse', 'pharmacy', 'staff'],
    },
  ];

  const allowedNav = navItems.filter((item) => item.roles.includes(role));

  const content = (
    <div className="flex flex-col h-full bg-slate-900 text-slate-300">
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-5 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
            <HeartPulse className="w-5 h-5 text-cyan-200" />
          </div>
          <div className="overflow-hidden">
            <h1 className="font-bold text-sm text-white tracking-tight truncate">
              {clinic?.name || 'MedFlow'}
            </h1>
            <p className="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider">
              Clinical SaaS
            </p>
          </div>
        </div>

        {/* Mobile close button */}
        <button
          onClick={onCloseMobile}
          className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1 scrollbar-thin scrollbar-thumb-slate-800">
        <div className="px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
          Main Modules
        </div>

        {allowedNav.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                onSelectTab(item.id);
                onCloseMobile();
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition group ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 font-bold'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/80'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition ${
                  isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'
                }`}
              />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* User Footer Card */}
      <div className="p-3 border-t border-slate-800">
        <div className="bg-slate-800/60 rounded-xl p-2.5 flex items-center justify-between border border-slate-800/80 hover:border-slate-700 transition">
          <div className="flex items-center gap-2.5 overflow-hidden min-w-0">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center shrink-0 shadow-xs">
              {currentUser?.fullName.charAt(0) || 'A'}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-slate-200 truncate">
                {currentUser?.fullName || 'Administrator'}
              </p>
              <p className="text-[10px] text-cyan-400 uppercase font-mono tracking-wider font-semibold">
                {currentUser?.role || 'admin'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsLogoutModalOpen(true)}
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition shrink-0 cursor-pointer"
            title="Log out of clinic session"
            aria-label="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 h-screen sticky top-0 border-r border-slate-800 z-40">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={onCloseMobile}
          />
          <div className="fixed inset-y-0 left-0 w-72 bg-slate-900 shadow-2xl">
            {content}
          </div>
        </div>
      )}

      {/* Logout Confirmation Modal */}
      <LogoutConfirmationModal
        isOpen={isLogoutModalOpen}
        onClose={() => setIsLogoutModalOpen(false)}
      />
    </>
  );
};
