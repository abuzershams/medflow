import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { LogoutConfirmationModal } from '../common/LogoutConfirmationModal';
import {
  Menu,
  Search,
  Bell,
  Plus,
  User,
  LogOut,
  KeyRound,
  Building2,
  Calendar,
  AlertTriangle,
} from 'lucide-react';

interface HeaderProps {
  onToggleSidebar: () => void;
  onOpenGlobalSearch: () => void;
  onQuickAction: (action: 'patient' | 'appointment' | 'consultation' | 'prescription' | 'invoice') => void;
  lowStockCount: number;
  todayAppointmentsCount: number;
  onNavigateTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  onOpenGlobalSearch,
  onQuickAction,
  lowStockCount,
  todayAppointmentsCount,
  onNavigateTab,
}) => {
  const { currentUser, clinic } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  const roleBadgeColors: Record<string, string> = {
    admin: 'bg-purple-100 text-purple-700 border-purple-200',
    doctor: 'bg-blue-100 text-blue-700 border-blue-200',
    receptionist: 'bg-teal-100 text-teal-700 border-teal-200',
    nurse: 'bg-rose-100 text-rose-700 border-rose-200',
    pharmacy: 'bg-amber-100 text-amber-700 border-amber-200',
    staff: 'bg-slate-100 text-slate-700 border-slate-200',
  };

  const totalAlerts = (lowStockCount > 0 ? 1 : 0) + (todayAppointmentsCount > 0 ? 1 : 0);

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 shadow-xs">
      {/* Left: Mobile Toggle & Clinic Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition lg:hidden"
          title="Toggle Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="hidden sm:block">
          <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>{clinic?.name || 'Clinic Management'}</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200">
              Live EMR
            </span>
          </h2>
          <p className="text-[11px] text-slate-500">
            {clinic?.doctorName || 'Lead Physician'}
          </p>
        </div>
      </div>

      {/* Middle: Global Search Trigger */}
      <div className="flex-1 max-w-md mx-4">
        <button
          onClick={onOpenGlobalSearch}
          className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-400 text-xs transition group cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <Search className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition" />
            <span className="text-slate-500">Search patients, appointments, Rx, invoices...</span>
          </span>
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono font-medium text-slate-400 bg-white border border-slate-200 rounded">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Quick Action Button */}
        <div className="relative">
          <button
            onClick={() => setShowQuickMenu(!showQuickMenu)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs hover:shadow transition"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Action</span>
          </button>

          {showQuickMenu && (
            <div
              className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-40 text-xs"
              onClick={() => setShowQuickMenu(false)}
            >
              <button
                onClick={() => onQuickAction('patient')}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                <span>+ New Patient</span>
              </button>
              <button
                onClick={() => onQuickAction('appointment')}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-indigo-500" />
                <span>+ New Appointment</span>
              </button>
              <button
                onClick={() => onQuickAction('consultation')}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-teal-500" />
                <span>+ Start OPD Consultation</span>
              </button>
              <button
                onClick={() => onQuickAction('prescription')}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>+ Create Prescription</span>
              </button>
              <button
                onClick={() => onQuickAction('invoice')}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-50 text-slate-700 font-medium flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span>+ Create Invoice</span>
              </button>
            </div>
          )}
        </div>

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition relative"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {totalAlerts > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white" />
            )}
          </button>

          {showNotifications && (
            <div
              className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-3 z-40 text-xs"
              onClick={() => setShowNotifications(false)}
            >
              <h4 className="font-bold text-slate-800 pb-2 border-b border-slate-100 flex items-center justify-between">
                <span>Clinic Alerts</span>
                <span className="text-[10px] text-slate-400 font-normal">Active monitors</span>
              </h4>

              <div className="py-2 space-y-2">
                {todayAppointmentsCount > 0 ? (
                  <div
                    onClick={() => onNavigateTab('appointments')}
                    className="p-2 rounded-lg bg-blue-50/60 hover:bg-blue-100/60 cursor-pointer flex items-start gap-2.5 transition"
                  >
                    <Calendar className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-slate-800">
                        {todayAppointmentsCount} Appointments Scheduled
                      </p>
                      <p className="text-[10px] text-slate-500">Scheduled for today</p>
                    </div>
                  </div>
                ) : null}

                {lowStockCount > 0 ? (
                  <div
                    onClick={() => onNavigateTab('inventory')}
                    className="p-2 rounded-lg bg-amber-50/60 hover:bg-amber-100/60 cursor-pointer flex items-start gap-2.5 transition"
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-slate-800">
                        {lowStockCount} Low Stock Medicines
                      </p>
                      <p className="text-[10px] text-slate-500">Require stock reorder</p>
                    </div>
                  </div>
                ) : null}

                {totalAlerts === 0 && (
                  <div className="py-4 text-center text-slate-400 text-xs">
                    No urgent clinic alerts at this time.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-blue-700 text-white font-bold flex items-center justify-center text-xs shadow-xs">
              {currentUser?.fullName.charAt(0) || 'U'}
            </div>
            <div className="hidden md:block text-left">
              <p className="text-xs font-semibold text-slate-800 leading-tight">
                {currentUser?.fullName || 'Staff User'}
              </p>
              <span
                className={`text-[10px] uppercase font-bold px-1.5 py-0.2 rounded border inline-block ${
                  roleBadgeColors[currentUser?.role || 'staff']
                }`}
              >
                {currentUser?.role || 'Staff'}
              </span>
            </div>
          </button>

          {showUserMenu && (
            <div
              className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-40 text-xs"
              onClick={() => setShowUserMenu(false)}
            >
              <div className="px-3.5 py-2 border-b border-slate-100">
                <p className="font-semibold text-slate-900">{currentUser?.fullName}</p>
                <p className="text-[11px] text-slate-400">@{currentUser?.username}</p>
              </div>

              <button
                onClick={() => onNavigateTab('settings')}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-50 text-slate-700 flex items-center gap-2.5 transition"
              >
                <Building2 className="w-4 h-4 text-slate-400" />
                <span>Clinic Profile</span>
              </button>

              <button
                onClick={() => onNavigateTab('settings')}
                className="w-full px-3.5 py-2 text-left hover:bg-slate-50 text-slate-700 flex items-center gap-2.5 transition"
              >
                <KeyRound className="w-4 h-4 text-slate-400" />
                <span>Change Password</span>
              </button>

              <div className="border-t border-slate-100 my-1" />

              <button
                onClick={() => setIsLogoutModalOpen(true)}
                className="w-full px-3.5 py-2 text-left hover:bg-rose-50 text-rose-600 font-semibold flex items-center gap-2.5 transition cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Logout Confirmation Modal */}
      <LogoutConfirmationModal
        isOpen={isLogoutModalOpen}
        onClose={() => setIsLogoutModalOpen(false)}
      />
    </header>
  );
};
