import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { saveClinicInfo, createStaffUser, hashPassword, seedStarterMedicinesIfEmpty, recordAudit } from '../../services/db';
import {
  ShieldCheck,
  Building2,
  UserCheck,
  Eye,
  EyeOff,
  CheckCircle2,
  Stethoscope,
  Phone,
  MapPin,
  Lock,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

export const InitialSetupView: React.FC = () => {
  const { checkInitialStatus } = useAuth();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Admin Account Details
  const [adminUsername, setAdminUsername] = useState('doctoradmin');
  const [adminFullName, setAdminFullName] = useState('Dr. Alex Morgan');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminConfirmPassword, setAdminConfirmPassword] = useState('');

  // Clinic Information
  const [clinicName, setClinicName] = useState('Hopewell Medical Care Clinic');
  const [doctorName, setDoctorName] = useState('Dr. Alex Morgan');
  const [qualification, setQualification] = useState('MBBS, MD (General Medicine)');
  const [registrationNumber, setRegistrationNumber] = useState('MED-REG-84920');
  const [clinicPhone, setClinicPhone] = useState('+1 (555) 392-1084');
  const [clinicAddress, setClinicAddress] = useState('Suite 400, 742 Evergreen Healthcare Blvd, Metro City');
  const [workingHours, setWorkingHours] = useState('Mon - Sat: 08:30 AM - 07:30 PM');
  const [clinicEmail, setClinicEmail] = useState('contact@hopewellclinic.com');

  const handleStep1Next = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!adminUsername.trim()) {
      setError('Username is required.');
      return;
    }
    if (adminUsername.trim().length < 3) {
      setError('Username must be at least 3 characters.');
      return;
    }
    if (!adminPassword) {
      setError('Password is required.');
      return;
    }
    if (adminPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (adminPassword !== adminConfirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    setStep(2);
  };

  const handleCompleteSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!clinicName.trim() || !doctorName.trim() || !clinicPhone.trim() || !clinicAddress.trim()) {
      setError('Please fill in all required clinic details.');
      return;
    }

    setLoading(true);
    try {
      // 1. Create password hash
      const passwordHash = await hashPassword(adminPassword);

      // 2. Save Clinic Info
      await saveClinicInfo({
        name: clinicName.trim(),
        doctorName: doctorName.trim(),
        qualification: qualification.trim(),
        registrationNumber: registrationNumber.trim(),
        phone: clinicPhone.trim(),
        whatsapp: clinicPhone.trim(),
        email: clinicEmail.trim(),
        address: clinicAddress.trim(),
        workingHours: workingHours.trim(),
        setupCompleted: true,
      });

      // 3. Create Administrator User
      const newAdmin = await createStaffUser({
        username: adminUsername.trim().toLowerCase(),
        fullName: adminFullName.trim() || doctorName.trim(),
        role: 'admin',
        phone: clinicPhone.trim(),
        email: clinicEmail.trim(),
        status: 'active',
        passwordHash,
      });

      // 4. Seed essential medical catalog
      await seedStarterMedicinesIfEmpty();

      // 5. Audit log
      await recordAudit('INITIAL_SETUP', 'Initial clinic setup completed and Admin account created', newAdmin.fullName, 'admin');

      setStep(3);
    } catch (err: any) {
      console.error('Setup failed:', err);
      setError(err.message || 'Failed to complete clinic setup. Please check database permissions.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8">
      {/* Container */}
      <div className="max-w-4xl w-full bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col md:flex-row">
        
        {/* Left Side: Brand Banner */}
        <div className="md:w-5/12 bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
                <Stethoscope className="w-7 h-7 text-cyan-300" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">MedFlow</h1>
                <p className="text-xs text-blue-200">Clinic Management System</p>
              </div>
            </div>

            <h2 className="text-2xl font-extrabold tracking-tight mb-3">
              One-Time System Initialization
            </h2>
            <p className="text-sm text-blue-100 leading-relaxed mb-6">
              Welcome to your dedicated clinic management suite. Configure your primary administrator account and clinic profile to secure your patient records.
            </p>

            {/* Stepper indicators */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                  step >= 1 ? 'bg-cyan-400 text-slate-900 shadow-md' : 'bg-white/20 text-white'
                }`}>
                  1
                </div>
                <div>
                  <p className="text-sm font-semibold">Administrator Account</p>
                  <p className="text-xs text-blue-200">Username & secure credentials</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                  step >= 2 ? 'bg-cyan-400 text-slate-900 shadow-md' : 'bg-white/20 text-white'
                }`}>
                  2
                </div>
                <div>
                  <p className="text-sm font-semibold">Clinic & Doctor Details</p>
                  <p className="text-xs text-blue-200">Letterhead and prescription info</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                  step === 3 ? 'bg-emerald-400 text-slate-900 shadow-md' : 'bg-white/20 text-white'
                }`}>
                  3
                </div>
                <div>
                  <p className="text-sm font-semibold">System Ready</p>
                  <p className="text-xs text-blue-200">Login and start managing</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/10 text-xs text-blue-200 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-300" />
            <span>Database Secured with Cloud Firestore & RLS</span>
          </div>
        </div>

        {/* Right Side: Step Forms */}
        <div className="md:w-7/12 p-6 sm:p-8 flex flex-col justify-center">
          {error && (
            <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-start gap-3">
              <span className="font-semibold text-rose-600">Error:</span>
              <span>{error}</span>
            </div>
          )}

          {step === 1 && (
            <form onSubmit={handleStep1Next} className="space-y-4">
              <div>
                <span className="text-xs font-bold tracking-wider text-blue-600 uppercase">Step 1 of 3</span>
                <h3 className="text-xl font-bold text-slate-900 mt-1">Create Administrator Account</h3>
                <p className="text-xs text-slate-500">
                  This primary account will have full access to manage patients, consultations, staff, and settings.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Admin Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={adminFullName}
                  onChange={(e) => setAdminFullName(e.target.value)}
                  placeholder="e.g. Dr. Alex Morgan"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Admin Username <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={adminUsername}
                    onChange={(e) => setAdminUsername(e.target.value)}
                    placeholder="e.g. doctoradmin"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm text-slate-800 pl-10"
                  />
                  <UserCheck className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">Use this username every time you log in.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Password <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      placeholder="Min. 6 characters"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm text-slate-800 pl-9 pr-10"
                    />
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Confirm Password <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={adminConfirmPassword}
                      onChange={(e) => setAdminConfirmPassword(e.target.value)}
                      placeholder="Re-type password"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm text-slate-800 pl-9 pr-10"
                    />
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <span>Continue to Clinic Profile</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={handleCompleteSetup} className="space-y-3.5 max-h-[520px] overflow-y-auto pr-1">
              <div>
                <span className="text-xs font-bold tracking-wider text-blue-600 uppercase">Step 2 of 3</span>
                <h3 className="text-xl font-bold text-slate-900 mt-1">Clinic & Doctor Details</h3>
                <p className="text-xs text-slate-500">
                  These details will appear on digital prescriptions, invoices, and clinical letterheads.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Clinic Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={clinicName}
                      onChange={(e) => setClinicName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm pl-9"
                    />
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Doctor / Clinic Head Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={doctorName}
                    onChange={(e) => setDoctorName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Medical Qualifications
                  </label>
                  <input
                    type="text"
                    value={qualification}
                    onChange={(e) => setQualification(e.target.value)}
                    placeholder="e.g. MBBS, MD, FRCS"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Medical Registration No.
                  </label>
                  <input
                    type="text"
                    value={registrationNumber}
                    onChange={(e) => setRegistrationNumber(e.target.value)}
                    placeholder="e.g. REG-123456"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Phone / WhatsApp <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={clinicPhone}
                      onChange={(e) => setClinicPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm pl-9"
                    />
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Clinic Email
                  </label>
                  <input
                    type="email"
                    value={clinicEmail}
                    onChange={(e) => setClinicEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Clinic Physical Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={clinicAddress}
                    onChange={(e) => setClinicAddress(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm pl-9"
                  />
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Working Hours
                </label>
                <input
                  type="text"
                  value={workingHours}
                  onChange={(e) => setWorkingHours(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="w-1/3 py-2.5 px-3 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-sm font-medium transition"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-2/3 py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {loading ? (
                    <span>Initializing System...</span>
                  ) : (
                    <>
                      <span>Complete Setup</span>
                      <Sparkles className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {step === 3 && (
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-2xl font-bold text-slate-900">Setup Completed!</h3>
                <p className="text-sm text-slate-600 max-w-sm mx-auto mt-2 leading-relaxed">
                  Your administrator account <strong className="text-slate-800">@{adminUsername}</strong> and <strong className="text-slate-800">{clinicName}</strong> have been configured securely.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left max-w-md mx-auto text-xs space-y-1.5 text-slate-600">
                <div className="flex justify-between">
                  <span className="font-semibold text-slate-700">Administrator:</span>
                  <span>{adminFullName} (@{adminUsername})</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-slate-700">Clinic Name:</span>
                  <span>{clinicName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-slate-700">Medicine Master:</span>
                  <span className="text-emerald-600 font-semibold">Starter formulary initialized</span>
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="button"
                  onClick={() => checkInitialStatus()}
                  className="w-full max-w-sm mx-auto py-3 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md hover:shadow-lg transition flex items-center justify-center gap-2"
                >
                  <span>Proceed to Login</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
