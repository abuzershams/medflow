import React, { useState } from 'react';
import { MedicalDocument, Patient } from '../../types';
import { addMedicalDocument, deleteMedicalDocument, recordAudit } from '../../services/db';
import { useAuth } from '../../context/AuthContext';
import {
  FolderArchive,
  Search,
  Plus,
  Filter,
  FileText,
  Image as ImageIcon,
  FileDown,
  Trash2,
  Eye,
  X,
  UploadCloud,
  User,
  Calendar,
  AlertCircle,
} from 'lucide-react';

interface DocumentsViewProps {
  documents: MedicalDocument[];
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
}

export function DocumentsView({ documents, patients, onSelectPatient }: DocumentsViewProps) {
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedPatientId, setSelectedPatientId] = useState<string>('all');

  // Upload Modal
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [patientId, setPatientId] = useState('');
  const [docType, setDocType] = useState<MedicalDocument['documentType']>('lab_report');
  const [notes, setNotes] = useState('');
  const [fileBase64, setFileBase64] = useState<string>('');
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  // Preview Modal
  const [previewDoc, setPreviewDoc] = useState<MedicalDocument | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError('File size exceeds 5MB limit. Please select a smaller file or compressed image.');
      return;
    }
    setError('');
    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + ' KB');

    const reader = new FileReader();
    reader.onloadend = () => {
      setFileBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !patientId || !fileBase64) {
      setError('Please provide document title, patient, and select a file.');
      return;
    }

    const patient = patients.find((p) => p.id === patientId);
    if (!patient) return;

    setIsSubmitting(true);
    try {
      await addMedicalDocument({
        patientId,
        patientName: patient.fullName,
        title: title.trim(),
        documentType: docType,
        fileUrl: fileBase64,
        fileName,
        fileSize,
        notes: notes.trim(),
        uploadedBy: currentUser?.fullName || 'Staff',
      });

      await recordAudit(
        'Upload Medical Document',
        `Uploaded ${docType} "${title}" for patient ${patient.fullName}`,
        currentUser?.fullName || 'Staff',
        currentUser?.role || 'staff',
        'document'
      );

      setIsUploadOpen(false);
      setTitle('');
      setPatientId('');
      setFileBase64('');
      setFileName('');
      setFileSize('');
      setNotes('');
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to upload document');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (doc: MedicalDocument) => {
    if (window.confirm(`Are you sure you want to delete document "${doc.title}"?`)) {
      try {
        await deleteMedicalDocument(doc.id);
        await recordAudit(
          'Delete Medical Document',
          `Deleted document ${doc.title} (${doc.id})`,
          currentUser?.fullName || 'Staff',
          currentUser?.role || 'staff',
          'document',
          doc.id
        );
      } catch (err) {
        console.error('Failed to delete doc:', err);
      }
    }
  };

  const filteredDocs = documents.filter((d) => {
    const matchesSearch =
      d.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.patientName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || d.documentType === selectedType;
    const matchesPatient = selectedPatientId === 'all' || d.patientId === selectedPatientId;
    return matchesSearch && matchesType && matchesPatient;
  });

  const getTypeBadge = (type: MedicalDocument['documentType']) => {
    switch (type) {
      case 'lab_report':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-700">Lab Report</span>;
      case 'x_ray':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-700">X-Ray / Scan</span>;
      case 'mri_ct':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700">MRI / CT</span>;
      case 'discharge_summary':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">Discharge</span>;
      case 'prescription':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">External Rx</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700">Other</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <FolderArchive className="w-7 h-7 text-teal-600" />
            Medical Documents & Records
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Store and retrieve lab reports, diagnostic imaging, and external health records
          </p>
        </div>

        <button
          onClick={() => setIsUploadOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition font-medium shadow-sm cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          Upload Document
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search documents by title or patient name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm"
          />
        </div>

        <div className="flex flex-wrap sm:flex-nowrap gap-3">
          <div className="flex items-center gap-2 min-w-36">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
            >
              <option value="all">All Document Types</option>
              <option value="lab_report">Lab Reports</option>
              <option value="x_ray">X-Ray & Imaging</option>
              <option value="mri_ct">MRI & CT Scans</option>
              <option value="discharge_summary">Discharge Summaries</option>
              <option value="prescription">External Prescriptions</option>
              <option value="other">Other Documents</option>
            </select>
          </div>

          <div className="min-w-44">
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
            >
              <option value="all">All Patients</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.fullName} ({p.patientId})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Document Grid / Cards */}
      {filteredDocs.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <FolderArchive className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-800">No medical documents found</h3>
          <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
            {searchTerm || selectedType !== 'all' || selectedPatientId !== 'all'
              ? 'Try modifying your search or filter criteria'
              : 'Start uploading diagnostic files, lab results, and reports for patients'}
          </p>
          <button
            onClick={() => setIsUploadOpen(true)}
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-teal-50 text-teal-700 hover:bg-teal-100 rounded-lg text-sm font-medium transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Upload First Document
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocs.map((doc) => {
            const isImage = doc.fileUrl?.startsWith('data:image/');
            const patient = patients.find((p) => p.id === doc.patientId);

            return (
              <div
                key={doc.id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition flex flex-col"
              >
                {/* Preview Thumbnail */}
                <div className="h-36 bg-slate-100 relative overflow-hidden flex items-center justify-center border-b border-slate-100">
                  {isImage ? (
                    <img
                      src={doc.fileUrl}
                      alt={doc.title}
                      className="w-full h-full object-cover cursor-pointer hover:scale-105 transition duration-200"
                      onClick={() => setPreviewDoc(doc)}
                    />
                  ) : (
                    <div
                      className="text-center p-4 cursor-pointer"
                      onClick={() => setPreviewDoc(doc)}
                    >
                      <FileText className="w-12 h-12 text-slate-400 mx-auto mb-1" />
                      <span className="text-xs text-slate-500 font-mono">
                        {doc.fileName || 'PDF Document'}
                      </span>
                    </div>
                  )}

                  <div className="absolute top-2 left-2">
                    {getTypeBadge(doc.documentType)}
                  </div>

                  {doc.fileSize && (
                    <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-slate-900/70 text-[10px] text-white font-mono backdrop-blur-xs">
                      {doc.fileSize}
                    </div>
                  )}
                </div>

                {/* Body Details */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-semibold text-slate-900 text-base line-clamp-1">
                      {doc.title}
                    </h3>

                    <div className="mt-2 space-y-1 text-xs text-slate-600">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Patient:</span>
                        <button
                          onClick={() => patient && onSelectPatient(patient)}
                          className="font-medium text-teal-600 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <User className="w-3.5 h-3.5" />
                          {doc.patientName}
                        </button>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Uploaded:</span>
                        <span className="flex items-center gap-1 text-slate-700">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          {new Date(doc.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">By:</span>
                        <span className="text-slate-700">{doc.uploadedBy}</span>
                      </div>
                    </div>

                    {doc.notes && (
                      <p className="mt-2 text-xs text-slate-500 bg-slate-50 p-2 rounded-md line-clamp-2">
                        {doc.notes}
                      </p>
                    )}
                  </div>

                  {/* Actions Bar */}
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => setPreviewDoc(doc)}
                      className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-600 hover:text-teal-700 px-2 py-1 rounded hover:bg-teal-50 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      View Full
                    </button>

                    <div className="flex items-center gap-1">
                      <a
                        href={doc.fileUrl}
                        download={doc.fileName || `${doc.title}.png`}
                        className="p-1.5 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded cursor-pointer"
                        title="Download file"
                      >
                        <FileDown className="w-4 h-4" />
                      </a>
                      <button
                        onClick={() => handleDelete(doc)}
                        className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded cursor-pointer"
                        title="Delete document"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload Modal */}
      {isUploadOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <UploadCloud className="w-5 h-5 text-teal-600" />
                Upload Medical Document
              </h2>
              <button
                onClick={() => setIsUploadOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <form onSubmit={handleUploadSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Patient <span className="text-rose-500">*</span>
                </label>
                <select
                  required
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  <option value="">Select Patient...</option>
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.fullName} ({p.patientId}) - {p.phone}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Document Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Complete Blood Count (CBC) Report"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Document Type
                </label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  <option value="lab_report">Lab Report / Pathology</option>
                  <option value="x_ray">X-Ray / Ultrasound</option>
                  <option value="mri_ct">MRI / CT Scan</option>
                  <option value="discharge_summary">Discharge Summary</option>
                  <option value="prescription">External Prescription</option>
                  <option value="other">Other Document</option>
                </select>
              </div>

              {/* File input */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select File (Image / PDF up to 5MB) <span className="text-rose-500">*</span>
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 border-dashed rounded-xl hover:border-teal-500 transition">
                  <div className="space-y-1 text-center">
                    <UploadCloud className="mx-auto h-10 w-10 text-slate-400" />
                    <div className="flex text-sm text-slate-600 justify-center">
                      <label className="relative cursor-pointer bg-white rounded-md font-medium text-teal-600 hover:text-teal-500 focus-within:outline-none">
                        <span>Upload a file</span>
                        <input
                          type="file"
                          accept="image/*,application/pdf"
                          onChange={handleFileChange}
                          className="sr-only"
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-slate-500">
                      PNG, JPG, WebP, PDF (Max 5MB)
                    </p>
                    {fileName && (
                      <p className="text-xs font-medium text-teal-600 mt-2 bg-teal-50 py-1 px-2 rounded">
                        Selected: {fileName} ({fileSize})
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Notes / Observations (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Doctor or lab observations regarding this document..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsUploadOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 text-sm font-medium shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'Uploading...' : 'Save Document'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Full Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                  {previewDoc.title}
                  {getTypeBadge(previewDoc.documentType)}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Patient: {previewDoc.patientName} • Uploaded by {previewDoc.uploadedBy} on{' '}
                  {new Date(previewDoc.createdAt).toLocaleString()}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewDoc.fileUrl}
                  download={previewDoc.fileName || `${previewDoc.title}.png`}
                  className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-lg"
                  title="Download"
                >
                  <FileDown className="w-5 h-5" />
                </a>
                <button
                  onClick={() => setPreviewDoc(null)}
                  className="p-2 text-slate-400 hover:text-slate-700 rounded-lg"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 flex-1 overflow-y-auto flex items-center justify-center bg-slate-900/5">
              {previewDoc.fileUrl?.startsWith('data:image/') ? (
                <img
                  src={previewDoc.fileUrl}
                  alt={previewDoc.title}
                  className="max-h-[65vh] max-w-full rounded-lg shadow-sm object-contain"
                />
              ) : (
                <div className="w-full h-[65vh] flex flex-col items-center justify-center bg-white rounded-xl border border-slate-200 p-8">
                  <FileText className="w-20 h-20 text-slate-400 mb-4" />
                  <p className="text-base font-semibold text-slate-800">{previewDoc.fileName}</p>
                  <p className="text-sm text-slate-500 mt-1">PDF Document ({previewDoc.fileSize})</p>
                  <a
                    href={previewDoc.fileUrl}
                    download={previewDoc.fileName || 'document.pdf'}
                    className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 text-sm font-medium shadow-sm"
                  >
                    <FileDown className="w-4 h-4" />
                    Download and View PDF
                  </a>
                </div>
              )}
            </div>

            {previewDoc.notes && (
              <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-700">
                <span className="font-semibold text-slate-900">Notes: </span>
                {previewDoc.notes}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
