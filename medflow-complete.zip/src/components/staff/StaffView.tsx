import React, { useState } from 'react';
import { UserStaff, UserRole } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  createStaffUser,
  updateStaffUser,
  deleteStaffUser,
  hashPassword,
  recordAudit,
} from '../../services/db';
import {
  Users,
  Shield,
  Plus,
  Edit2,
  Trash2,
  KeyRound,
  CheckCircle2,
  XCircle,
  AlertCircle,
  X,
  Lock,
  User,
  Phone,
  Mail,
  ShieldCheck,
  Eye,
  EyeOff,
  Search,
} from 'lucide-react';

interface StaffViewProps {
  staffList: UserStaff[];
  onReloadStaff?: () => void;
}

export function StaffView({ staffList, onReloadStaff }: StaffViewProps) {
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');

  // Add / Edit Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<UserStaff | null>(null);

  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<UserRole>('receptionist');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const openAddModal = () => {
    setEditingStaff(null);
    setUsername('');
    setFullName('');
    setRole('receptionist');
    setPhone('');
    setEmail('');
    setPassword('');
    setStatus('active');
    setError('');
    setIsModalOpen(true);
  };

  const openEditModal = (staff: UserStaff) => {
    setEditingStaff(staff);
    setUsername(staff.username);
    setFullName(staff.fullName);
    setRole(staff.role);
    setPhone(staff.phone || '');
    setEmail(staff.email || '');
    setPassword(''); // leave blank if keeping same
    setStatus(staff.status);
    setError('');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !fullName.trim()) {
      setError('Please provide a valid username and staff full name');
      return;
    }

    if (!editingStaff && (!password || password.length < 6)) {
      setError('Password must be at least 6 characters');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingStaff) {
        const updates: Partial<UserStaff> = {
          fullName: fullName.trim(),
          role,
          phone: phone.trim(),
          email: email.trim(),
          status,
        };

        if (password.trim()) {
          updates.passwordHash = await hashPassword(password);
        }

        await updateStaffUser(editingStaff.id, updates);
        await recordAudit(
          'Update Staff Member',
          `Updated staff profile for ${username} (${role})`,
          currentUser?.fullName || 'Admin',
          currentUser?.role || 'admin',
          'staff',
          editingStaff.id
        );
      } else {
        const pHash = await hashPassword(password);
        await createStaffUser({
          username: username.trim().toLowerCase(),
          fullName: fullName.trim(),
          role,
          phone: phone.trim(),
          email: email.trim(),
          status,
          passwordHash: pHash,
        });

        await recordAudit(
          'Create Staff Member',
          `Created user account for ${username} (${role})`,
          currentUser?.fullName || 'Admin',
          currentUser?.role || 'admin',
          'staff'
        );
      }

      setIsModalOpen(false);
      onReloadStaff?.();
    } catch (err: any) {
      setError(err.message || 'Operation failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteStaff = async (staff: UserStaff) => {
    if (staff.id === currentUser?.id) {
      alert('You cannot delete your own logged-in account.');
      return;
    }

    // Check if last admin
    if (staff.role === 'admin') {
      const activeAdmins = staffList.filter((s) => s.role === 'admin' && s.status === 'active');
      if (activeAdmins.length <= 1) {
        alert('Cannot delete the only active Administrator account in the system.');
        return;
      }
    }

    if (window.confirm(`Are you sure you want to permanently delete staff account "${staff.username}" (${staff.fullName})?`)) {
      try {
        await deleteStaffUser(staff.id);
        await recordAudit(
          'Delete Staff User',
          `Deleted staff account ${staff.username} (${staff.fullName})`,
          currentUser?.fullName || 'Admin',
          currentUser?.role || 'admin',
          'staff',
          staff.id
        );
        onReloadStaff?.();
      } catch (err: any) {
        alert('Failed to delete staff: ' + err.message);
      }
    }
  };

  const handleToggleStatus = async (staff: UserStaff) => {
    if (staff.id === currentUser?.id) {
      alert('You cannot deactivate your own account.');
      return;
    }

    const nextStatus = staff.status === 'active' ? 'inactive' : 'active';
    try {
      await updateStaffUser(staff.id, { status: nextStatus });
      await recordAudit(
        'Toggle Staff Status',
        `Changed status of ${staff.username} to ${nextStatus}`,
        currentUser?.fullName || 'Admin',
        currentUser?.role || 'admin',
        'staff',
        staff.id
      );
      onReloadStaff?.();
    } catch (err: any) {
      alert('Failed to update status: ' + err.message);
    }
  };

  const getRoleBadge = (r: UserRole) => {
    switch (r) {
      case 'admin':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800">Admin</span>;
      case 'doctor':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800">Doctor</span>;
      case 'receptionist':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">Receptionist</span>;
      case 'nurse':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800">Nurse</span>;
      case 'pharmacy':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">Pharmacy</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">General Staff</span>;
    }
  };

  const filteredStaff = staffList.filter((s) => {
    const matchesSearch =
      s.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.phone && s.phone.includes(searchTerm));
    const matchesRole = roleFilter === 'all' || s.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-7 h-7 text-teal-600" />
            Staff & User Management
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage clinic employees, assign role-based permissions, and manage credentials
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition font-medium shadow-sm cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          Add Staff Member
        </button>
      </div>

      {/* Role Permissions Reference Cards */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <h3 className="font-bold text-slate-900 text-sm mb-3 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-teal-600" />
          Role Permissions Matrix
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          <div className="p-3 bg-rose-50/50 rounded-lg border border-rose-100">
            <span className="font-bold text-rose-800 block mb-1">Admin</span>
            <p className="text-rose-700">Full system access: Staff, Settings, Invoicing, Clinical, Inventory & Reports.</p>
          </div>
          <div className="p-3 bg-teal-50/50 rounded-lg border border-teal-100">
            <span className="font-bold text-teal-800 block mb-1">Doctor</span>
            <p className="text-teal-700">Patients, Appointments, Vitals, OPD Consultations, Prescriptions & Records.</p>
          </div>
          <div className="p-3 bg-blue-50/50 rounded-lg border border-blue-100">
            <span className="font-bold text-blue-800 block mb-1">Receptionist</span>
            <p className="text-blue-700">Patient registration, Appointment scheduling, Billing & Payment collection.</p>
          </div>
          <div className="p-3 bg-purple-50/50 rounded-lg border border-purple-100">
            <span className="font-bold text-purple-800 block mb-1">Nurse</span>
            <p className="text-purple-700">Patient check-in, Recording clinical vitals & Appointment queue management.</p>
          </div>
          <div className="p-3 bg-amber-50/50 rounded-lg border border-amber-100">
            <span className="font-bold text-amber-800 block mb-1">Pharmacy</span>
            <p className="text-amber-700">Medicines database, Stock movements, Supplier purchases & Inventory audits.</p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search staff by full name, username, or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm"
          />
        </div>

        <div className="flex items-center gap-2 min-w-40">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 bg-white"
          >
            <option value="all">All Roles</option>
            <option value="admin">Administrator</option>
            <option value="doctor">Doctor</option>
            <option value="receptionist">Receptionist</option>
            <option value="nurse">Nurse</option>
            <option value="pharmacy">Pharmacy Staff</option>
            <option value="staff">General Staff</option>
          </select>
        </div>
      </div>

      {/* Staff Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-semibold text-xs border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Username</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Phone / Contact</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Created Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredStaff.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No staff users found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredStaff.map((staff) => (
                  <tr key={staff.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs uppercase">
                          {staff.fullName.charAt(0)}
                        </div>
                        <div>
                          <span>{staff.fullName}</span>
                          {staff.id === currentUser?.id && (
                            <span className="ml-2 text-[10px] font-bold text-teal-600 bg-teal-50 px-1.5 py-0.5 rounded">
                              (You)
                            </span>
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-600">
                      @{staff.username}
                    </td>

                    <td className="py-3 px-4">
                      {getRoleBadge(staff.role)}
                    </td>

                    <td className="py-3 px-4 text-slate-600">
                      <div>{staff.phone || '—'}</div>
                      {staff.email && <div className="text-xs text-slate-400">{staff.email}</div>}
                    </td>

                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleToggleStatus(staff)}
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold cursor-pointer ${
                          staff.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                            : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                        }`}
                        title="Click to toggle status"
                      >
                        {staff.status === 'active' ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            Active
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3 h-3" />
                            Inactive
                          </>
                        )}
                      </button>
                    </td>

                    <td className="py-3 px-4 text-xs text-slate-500">
                      {new Date(staff.createdAt).toLocaleDateString()}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEditModal(staff)}
                          className="p-1.5 text-slate-500 hover:text-teal-600 hover:bg-teal-50 rounded cursor-pointer"
                          title="Edit staff & password"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteStaff(staff)}
                          disabled={staff.id === currentUser?.id}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                          title="Delete user"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-teal-600" />
                {editingStaff ? `Edit Staff: @${editingStaff.username}` : 'Add New Staff Member'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Username <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  disabled={!!editingStaff}
                  placeholder="e.g. sarah_nurse"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none disabled:bg-slate-100 disabled:text-slate-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sarah Jenkins, RN"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Role <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 bg-white"
                  >
                    <option value="doctor">Doctor</option>
                    <option value="receptionist">Receptionist</option>
                    <option value="nurse">Nurse</option>
                    <option value="pharmacy">Pharmacy Staff</option>
                    <option value="admin">Administrator</option>
                    <option value="staff">General Staff</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 bg-white"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    placeholder="e.g. 555-0199"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="staff@clinic.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {editingStaff ? 'New Password (Leave blank to keep existing)' : 'Login Password'}
                  {!editingStaff && <span className="text-rose-500">*</span>}
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required={!editingStaff}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 pr-10 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">Minimum 6 characters</p>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 text-sm font-medium shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingStaff ? 'Save Changes' : 'Create Staff'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
