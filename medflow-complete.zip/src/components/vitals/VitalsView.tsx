import React, { useState } from 'react';
import { Vital, Patient } from '../../types';
import {
  Activity,
  Plus,
  Search,
  Heart,
  Thermometer,
  Gauge,
  Droplet,
  User,
  Clock,
} from 'lucide-react';

interface VitalsViewProps {
  vitals: Vital[];
  patients: Patient[];
  onOpenRecordModal: () => void;
  onSelectPatient: (patient: Patient) => void;
}

export const VitalsView: React.FC<VitalsViewProps> = ({
  vitals,
  patients,
  onOpenRecordModal,
  onSelectPatient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredVitals = vitals.filter((v) => {
    const term = searchTerm.toLowerCase();
    const pName = v.patientName?.toLowerCase() || '';
    const recBy = v.recordedBy.toLowerCase();
    return pName.includes(term) || recBy.includes(term) || v.recordedAt.includes(term);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-600" />
            <span>Patient Vitals & Biometrics</span>
          </h2>
          <p className="text-xs text-slate-500">
            {vitals.length} total biometric reading(s) stored in database
          </p>
        </div>

        <button
          onClick={onOpenRecordModal}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs hover:shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>+ Record Vitals</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
        <Search className="w-4 h-4 text-slate-400 shrink-0" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Filter vitals by patient name, recorded staff, or date..."
          className="w-full text-xs text-slate-800 outline-none"
        />
      </div>

      {/* Vitals Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredVitals.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <Activity className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-600 text-sm">No vital records found</p>
            <p className="mt-1 text-slate-400">Click "+ Record Vitals" to enter patient biometric readings.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Blood Pressure</th>
                  <th className="py-3 px-4">Pulse Rate</th>
                  <th className="py-3 px-4">SpO2 Oxygen</th>
                  <th className="py-3 px-4">Temp (°F)</th>
                  <th className="py-3 px-4">BMI</th>
                  <th className="py-3 px-4">Staff</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredVitals.map((v) => {
                  const isHighBp = (v.bpSystolic && v.bpSystolic >= 140) || (v.bpDiastolic && v.bpDiastolic >= 90);
                  const isLowSpo2 = v.spo2 && v.spo2 < 95;

                  return (
                    <tr key={v.id} className="hover:bg-slate-50 transition">
                      <td className="py-3.5 px-4 font-mono text-slate-600">
                        {v.recordedAt.replace('T', ' ').substring(0, 16)}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-900">{v.patientName || 'Patient'}</span>
                        {v.notes && <p className="text-[10px] text-slate-400 italic truncate max-w-xs">{v.notes}</p>}
                      </td>

                      <td className="py-3.5 px-4">
                        {v.bpSystolic && v.bpDiastolic ? (
                          <span
                            className={`font-mono font-bold px-2 py-0.5 rounded ${
                              isHighBp ? 'bg-rose-100 text-rose-800 font-extrabold' : 'bg-slate-100 text-slate-800'
                            }`}
                          >
                            {v.bpSystolic}/{v.bpDiastolic} mmHg
                          </span>
                        ) : (
                          <span className="text-slate-400">--</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono font-semibold text-slate-700">
                        {v.pulse ? `${v.pulse} bpm` : '--'}
                      </td>

                      <td className="py-3.5 px-4">
                        {v.spo2 ? (
                          <span
                            className={`font-mono font-bold px-2 py-0.5 rounded ${
                              isLowSpo2 ? 'bg-amber-100 text-amber-800' : 'text-slate-800'
                            }`}
                          >
                            {v.spo2}%
                          </span>
                        ) : (
                          <span className="text-slate-400">--</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-slate-700 font-mono">
                        {v.temperature ? `${v.temperature}°F` : '--'}
                      </td>

                      <td className="py-3.5 px-4">
                        {v.bmi ? (
                          <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                            {v.bmi}
                          </span>
                        ) : (
                          <span className="text-slate-400">--</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-slate-500 font-medium">
                        {v.recordedBy}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
