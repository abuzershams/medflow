import React, { useState, useMemo } from 'react';
import { printPage } from '../../local/printing';
import {
  Patient,
  Appointment,
  Consultation,
  Prescription,
  Invoice,
  Payment,
  Medicine,
} from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  BarChart3,
  TrendingUp,
  CreditCard,
  Users,
  Calendar,
  Pill,
  Download,
  Printer,
  DollarSign,
  Activity,
  FileText,
  Filter,
  CheckCircle2,
} from 'lucide-react';

interface ReportsViewProps {
  patients: Patient[];
  appointments: Appointment[];
  consultations: Consultation[];
  prescriptions: Prescription[];
  invoices: Invoice[];
  payments: Payment[];
  medicines: Medicine[];
}

export function ReportsView({
  patients,
  appointments,
  consultations,
  prescriptions,
  invoices,
  payments,
  medicines,
}: ReportsViewProps) {
  const { clinic } = useAuth();
  const [dateFilter, setDateFilter] = useState<'today' | '7days' | 'month' | 'all'>('month');
  const [reportSection, setReportSection] = useState<'financial' | 'opd' | 'patients' | 'pharmacy'>('financial');

  // Filter calculations based on date
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  const filteredData = useMemo(() => {
    let startDate = new Date();
    if (dateFilter === 'today') {
      startDate.setHours(0, 0, 0, 0);
    } else if (dateFilter === '7days') {
      startDate.setDate(now.getDate() - 7);
    } else if (dateFilter === 'month') {
      startDate.setDate(1);
      startDate.setHours(0, 0, 0, 0);
    } else {
      startDate = new Date(0); // all time
    }

    const startISO = startDate.toISOString().split('T')[0];

    const fInvoices = invoices.filter((i) => dateFilter === 'all' || i.date >= startISO);
    const fPayments = payments.filter((p) => dateFilter === 'all' || p.date >= startISO);
    const fAppointments = appointments.filter((a) => dateFilter === 'all' || a.date >= startISO);
    const fConsultations = consultations.filter((c) => dateFilter === 'all' || c.createdAt.split('T')[0] >= startISO);
    const fPrescriptions = prescriptions.filter((p) => dateFilter === 'all' || p.createdAt.split('T')[0] >= startISO);
    const fPatients = patients.filter((p) => dateFilter === 'all' || p.createdAt.split('T')[0] >= startISO);

    return {
      invoices: fInvoices,
      payments: fPayments,
      appointments: fAppointments,
      consultations: fConsultations,
      prescriptions: fPrescriptions,
      patients: fPatients,
    };
  }, [dateFilter, invoices, payments, appointments, consultations, prescriptions, patients]);

  // Financial aggregates
  const totalInvoiced = filteredData.invoices.reduce((acc, i) => acc + (i.total || 0), 0);
  const totalCollected = filteredData.payments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const totalDues = filteredData.invoices.reduce((acc, i) => acc + (i.dueAmount || 0), 0);

  // Payment method breakdown
  const methodTotals = filteredData.payments.reduce((acc, p) => {
    acc[p.method] = (acc[p.method] || 0) + p.amount;
    return acc;
  }, {} as Record<string, number>);

  // Pharmacy aggregates
  const lowStockCount = medicines.filter((m) => m.currentStock <= m.minStockLevel).length;
  const totalStockValue = medicines.reduce((acc, m) => acc + m.currentStock * m.price, 0);

  const handlePrint = () => {
    printPage(document.getElementById('report-print-area'), 'MedFlow-Report.pdf').catch((e) => alert(e.message));
  };

  const handleExportCSV = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    if (reportSection === 'financial') {
      csvContent += 'Invoice Number,Date,Patient,Total,Paid,Due,Status\n';
      filteredData.invoices.forEach((i) => {
        csvContent += `"${i.invoiceNumber}","${i.date}","${i.patientName}",${i.total},${i.paidAmount},${i.dueAmount},"${i.status}"\n`;
      });
    } else if (reportSection === 'opd') {
      csvContent += 'Date,Time,Patient,Phone,Doctor,Type,Status\n';
      filteredData.appointments.forEach((a) => {
        csvContent += `"${a.date}","${a.time}","${a.patientName}","${a.patientPhone}","${a.doctorName}","${a.type}","${a.status}"\n`;
      });
    } else {
      csvContent += 'Patient ID,Name,Age,Gender,Phone,Blood Group,City\n';
      filteredData.patients.forEach((p) => {
        csvContent += `"${p.patientId}","${p.fullName}",${p.age},"${p.gender}","${p.phone}","${p.bloodGroup}","${p.city}"\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `clinic_report_${reportSection}_${dateFilter}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="report-print-area" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-7 h-7 text-teal-600" />
            Clinic Reports & Analytics
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Real-time insights across clinic revenue, OPD attendance, patient flow, and pharmacy
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 text-sm font-medium transition cursor-pointer shadow-xs"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export CSV
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 text-sm font-medium transition cursor-pointer shadow-xs"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>
      </div>

      {/* Date Filter & Section selector */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 justify-between items-center">
        {/* Section Tabs */}
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          <button
            onClick={() => setReportSection('financial')}
            className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition cursor-pointer flex items-center gap-2 ${
              reportSection === 'financial'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            Financial & Revenue
          </button>
          <button
            onClick={() => setReportSection('opd')}
            className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition cursor-pointer flex items-center gap-2 ${
              reportSection === 'opd'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Calendar className="w-4 h-4" />
            OPD & Appointments
          </button>
          <button
            onClick={() => setReportSection('patients')}
            className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition cursor-pointer flex items-center gap-2 ${
              reportSection === 'patients'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            Patient Demographics
          </button>
          <button
            onClick={() => setReportSection('pharmacy')}
            className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition cursor-pointer flex items-center gap-2 ${
              reportSection === 'pharmacy'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Pill className="w-4 h-4" />
            Pharmacy & Inventory
          </button>
        </div>

        {/* Date Filter selector */}
        <div className="flex bg-slate-100 p-1 rounded-lg shrink-0">
          <button
            onClick={() => setDateFilter('today')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              dateFilter === 'today' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Today
          </button>
          <button
            onClick={() => setDateFilter('7days')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              dateFilter === '7days' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Last 7 Days
          </button>
          <button
            onClick={() => setDateFilter('month')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              dateFilter === 'month' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setDateFilter('all')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              dateFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Time
          </button>
        </div>
      </div>

      {/* SECTION: FINANCIAL & REVENUE */}
      {reportSection === 'financial' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Invoiced
              </span>
              <p className="text-2xl font-bold text-slate-900 mt-2">
                ${totalInvoiced.toLocaleString()}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {filteredData.invoices.length} invoices generated
              </p>
            </div>

            <div className="bg-emerald-50/50 p-5 rounded-xl border border-emerald-200 shadow-xs">
              <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
                Revenue Collected
              </span>
              <p className="text-2xl font-bold text-emerald-700 mt-2">
                ${totalCollected.toLocaleString()}
              </p>
              <p className="text-xs text-emerald-600 mt-1">
                {filteredData.payments.length} payment transactions
              </p>
            </div>

            <div className="bg-amber-50/50 p-5 rounded-xl border border-amber-200 shadow-xs">
              <span className="text-xs font-semibold text-amber-700 uppercase tracking-wider">
                Outstanding Balance
              </span>
              <p className="text-2xl font-bold text-amber-700 mt-2">
                ${totalDues.toLocaleString()}
              </p>
              <p className="text-xs text-amber-600 mt-1">Pending collection from patients</p>
            </div>
          </div>

          {/* Payment Method Breakdown */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <h3 className="font-bold text-slate-900 text-base mb-4 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-teal-600" />
              Collections by Payment Method
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {['cash', 'upi', 'card', 'bank_transfer'].map((m) => (
                <div key={m} className="p-4 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-xs font-semibold uppercase text-slate-500">
                    {m.replace('_', ' ')}
                  </span>
                  <p className="text-xl font-bold text-slate-900 mt-1">
                    ${(methodTotals[m] || 0).toLocaleString()}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {totalCollected > 0
                      ? (((methodTotals[m] || 0) / totalCollected) * 100).toFixed(1) + '%'
                      : '0%'}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Invoices Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Invoices in Selected Period</h3>
              <span className="text-xs text-slate-500 font-medium">
                {filteredData.invoices.length} Records
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-semibold text-xs border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Invoice #</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Patient</th>
                    <th className="py-3 px-4">Total</th>
                    <th className="py-3 px-4">Paid</th>
                    <th className="py-3 px-4">Due</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredData.invoices.slice(0, 15).map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono font-medium text-slate-900">
                        {inv.invoiceNumber}
                      </td>
                      <td className="py-3 px-4">{inv.date}</td>
                      <td className="py-3 px-4 font-medium">{inv.patientName}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">${inv.total}</td>
                      <td className="py-3 px-4 text-emerald-600 font-medium">${inv.paidAmount}</td>
                      <td className="py-3 px-4 text-amber-600 font-medium">${inv.dueAmount}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                            inv.status === 'paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : inv.status === 'partial'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: OPD & APPOINTMENTS */}
      {reportSection === 'opd' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Appointments
              </span>
              <p className="text-2xl font-bold text-slate-900 mt-2">
                {filteredData.appointments.length}
              </p>
            </div>

            <div className="bg-emerald-50/50 p-5 rounded-xl border border-emerald-200 shadow-xs">
              <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
                Completed Visits
              </span>
              <p className="text-2xl font-bold text-emerald-700 mt-2">
                {filteredData.appointments.filter((a) => a.status === 'completed').length}
              </p>
            </div>

            <div className="bg-blue-50/50 p-5 rounded-xl border border-blue-200 shadow-xs">
              <span className="text-xs font-semibold text-blue-700 uppercase tracking-wider">
                OPD Consultations
              </span>
              <p className="text-2xl font-bold text-blue-700 mt-2">
                {filteredData.consultations.length}
              </p>
            </div>

            <div className="bg-purple-50/50 p-5 rounded-xl border border-purple-200 shadow-xs">
              <span className="text-xs font-semibold text-purple-700 uppercase tracking-wider">
                Prescriptions Issued
              </span>
              <p className="text-2xl font-bold text-purple-700 mt-2">
                {filteredData.prescriptions.length}
              </p>
            </div>
          </div>

          {/* Appointment list */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">OPD Appointments Detail</h3>
              <span className="text-xs text-slate-500 font-medium">
                {filteredData.appointments.length} Recorded
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-semibold text-xs border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Time</th>
                    <th className="py-3 px-4">Patient</th>
                    <th className="py-3 px-4">Doctor</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Reason</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredData.appointments.slice(0, 15).map((app) => (
                    <tr key={app.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4">{app.date}</td>
                      <td className="py-3 px-4 font-mono">{app.time}</td>
                      <td className="py-3 px-4 font-medium text-slate-900">{app.patientName}</td>
                      <td className="py-3 px-4">{app.doctorName}</td>
                      <td className="py-3 px-4 capitalize">{app.type}</td>
                      <td className="py-3 px-4 text-slate-500">{app.reason}</td>
                      <td className="py-3 px-4 capitalize font-semibold">{app.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: PATIENT DEMOGRAPHICS */}
      {reportSection === 'patients' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Registered Patients
              </span>
              <p className="text-2xl font-bold text-slate-900 mt-2">{patients.length}</p>
              <p className="text-xs text-slate-400 mt-1">
                {filteredData.patients.length} added in this period
              </p>
            </div>

            <div className="bg-blue-50/50 p-5 rounded-xl border border-blue-200 shadow-xs">
              <span className="text-xs font-semibold text-blue-700 uppercase tracking-wider">
                Gender Breakdown
              </span>
              <p className="text-sm font-medium text-slate-800 mt-2">
                Male: {patients.filter((p) => p.gender === 'Male').length} | Female:{' '}
                {patients.filter((p) => p.gender === 'Female').length}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Other: {patients.filter((p) => p.gender === 'Other').length}
              </p>
            </div>

            <div className="bg-teal-50/50 p-5 rounded-xl border border-teal-200 shadow-xs">
              <span className="text-xs font-semibold text-teal-700 uppercase tracking-wider">
                Avg. Patient Age
              </span>
              <p className="text-2xl font-bold text-teal-700 mt-2">
                {patients.length > 0
                  ? Math.round(patients.reduce((acc, p) => acc + (p.age || 0), 0) / patients.length)
                  : 0}{' '}
                years
              </p>
            </div>
          </div>

          {/* Patient Directory */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Patients Registered</h3>
              <span className="text-xs text-slate-500 font-medium">{patients.length} Total</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-semibold text-xs border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Patient ID</th>
                    <th className="py-3 px-4">Full Name</th>
                    <th className="py-3 px-4">Age / Gender</th>
                    <th className="py-3 px-4">Mobile</th>
                    <th className="py-3 px-4">Blood Group</th>
                    <th className="py-3 px-4">City</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {patients.slice(0, 15).map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono font-medium text-teal-600">{p.patientId}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{p.fullName}</td>
                      <td className="py-3 px-4">
                        {p.age} yrs • {p.gender}
                      </td>
                      <td className="py-3 px-4">{p.phone}</td>
                      <td className="py-3 px-4 font-medium text-rose-600">{p.bloodGroup || '—'}</td>
                      <td className="py-3 px-4">{p.city || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: PHARMACY & INVENTORY */}
      {reportSection === 'pharmacy' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Medicine Catalog
              </span>
              <p className="text-2xl font-bold text-slate-900 mt-2">{medicines.length}</p>
              <p className="text-xs text-slate-400 mt-1">Formulations & brands registered</p>
            </div>

            <div className="bg-amber-50/50 p-5 rounded-xl border border-amber-200 shadow-xs">
              <span className="text-xs font-semibold text-amber-700 uppercase tracking-wider">
                Low Stock Alerts
              </span>
              <p className="text-2xl font-bold text-amber-700 mt-2">{lowStockCount}</p>
              <p className="text-xs text-amber-600 mt-1">Items at or below minimum threshold</p>
            </div>

            <div className="bg-emerald-50/50 p-5 rounded-xl border border-emerald-200 shadow-xs">
              <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
                Estimated Inventory Value
              </span>
              <p className="text-2xl font-bold text-emerald-700 mt-2">
                ${totalStockValue.toLocaleString()}
              </p>
              <p className="text-xs text-emerald-600 mt-1">Retail value on shelf</p>
            </div>
          </div>

          {/* Medicines inventory status table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">Medicine Stock & Replenishment Status</h3>
              <span className="text-xs text-slate-500 font-medium">{medicines.length} Items</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-semibold text-xs border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Medicine Name</th>
                    <th className="py-3 px-4">Generic</th>
                    <th className="py-3 px-4">Form / Strength</th>
                    <th className="py-3 px-4">Current Stock</th>
                    <th className="py-3 px-4">Min. Required</th>
                    <th className="py-3 px-4">Unit Price</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {medicines.map((m) => {
                    const isLow = m.currentStock <= m.minStockLevel;
                    return (
                      <tr key={m.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-semibold text-slate-900">{m.name}</td>
                        <td className="py-3 px-4 text-slate-500">{m.generic}</td>
                        <td className="py-3 px-4">
                          {m.form} • {m.strength}
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900">{m.currentStock}</td>
                        <td className="py-3 px-4 text-slate-500">{m.minStockLevel}</td>
                        <td className="py-3 px-4 font-medium">${m.price}</td>
                        <td className="py-3 px-4">
                          {isLow ? (
                            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800">
                              Low Stock
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                              Adequate
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
