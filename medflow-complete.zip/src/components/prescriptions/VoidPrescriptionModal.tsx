import React, { useState } from 'react';
import { AlertTriangle, Archive, X, Loader2, FileText } from 'lucide-react';
import { Prescription } from '../../types';

interface VoidPrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  prescription: Prescription | null;
  onConfirm: (reason: string) => Promise<void>;
  isLoading: boolean;
}

export const VoidPrescriptionModal: React.FC<VoidPrescriptionModalProps> = ({
  isOpen,
  onClose,
  prescription,
  onConfirm,
  isLoading,
}) => {
  const [reason, setReason] = useState('Treatment modified / Discontinued');

  if (!isOpen || !prescription) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 text-amber-600">
              <div className="w-9 h-9 rounded-xl bg-amber-50 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
              </div>
              <h3 className="font-bold text-slate-900 text-base">Void / Archive Prescription?</h3>
            </div>
            <button
              onClick={onClose}
              disabled={isLoading}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition cursor-pointer disabled:opacity-40"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600 shrink-0" />
              <p className="font-mono font-bold text-blue-700 text-sm">{prescription.prescriptionNumber}</p>
            </div>
            <div className="text-xs text-slate-600 space-y-0.5 pl-6 font-sans">
              <p>Patient: <strong className="text-slate-800">{prescription.patientName}</strong> ({prescription.patientAge} Yrs / {prescription.patientGender})</p>
              <p>Diagnosis: <strong className="text-slate-800">{prescription.diagnosis}</strong></p>
              <p>Prescribed Items: <span className="text-slate-800 font-semibold">{prescription.medicines?.length || 0} formulation(s)</span></p>
              <p className="text-[11px] text-slate-400">Date: {prescription.createdAt.split('T')[0]}</p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Reason for Voiding / Archiving:
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Dosage corrected, Adverse reaction, Discontinued"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            In accordance with medical record compliance, clinical prescriptions are <strong>archived & marked void</strong> rather than destructively removed.
          </p>

          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-200 transition cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => onConfirm(reason)}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 shadow-xs transition flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Archive className="w-4 h-4" />
                  <span>Confirm Void / Archive</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
