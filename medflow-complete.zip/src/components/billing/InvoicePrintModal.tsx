import React, { useEffect, useState, useRef } from 'react';
import { printPage, savePageAsPdf } from '../../local/printing';
import { Capacitor } from '@capacitor/core';
import { Invoice, Clinic } from '../../types';
import {
  X,
  Printer,
  Download,
  Phone,
  MapPin,
  Receipt,
  HeartPulse,
  AlertTriangle,
  Loader2,
  FileDown,
  RefreshCw,
  MessageCircle,
} from 'lucide-react';
import jsPDFPackage from 'jspdf';
import html2canvasPackage from 'html2canvas-pro';

interface InvoicePrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  clinic: Clinic | null;
  patientPhone?: string;
}

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({
  isOpen,
  onClose,
  invoice,
  clinic,
  patientPhone = '',
}) => {
  const [pdfError, setPdfError] = useState<string | null>(null);
  const [isPdfGenerating, setIsPdfGenerating] = useState(false);
  const [isSharingWhatsApp, setIsSharingWhatsApp] = useState(false);
  const printContentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setPdfError(null);
    setIsPdfGenerating(false);
    setIsSharingWhatsApp(false);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !invoice) return null;

  const cName = clinic?.name || 'Medical Clinic';
  const docName = clinic?.doctorName || 'Dr. Alex Morgan';
  const phone = clinic?.phone || '';
  const addr = clinic?.address || '';
  const activePhone = patientPhone || invoice.patientPhone || '';
  const safeInvoiceNo = invoice.invoiceNumber || 'INV-000';
  const pdfFileName = `Invoice-${safeInvoiceNo}.pdf`;

  const whatsappMessage = `Hello ${invoice.patientName},\n\nYour medical invoice from ${cName}:\nInvoice #: ${safeInvoiceNo}\nDate: ${invoice.date}\nTotal Amount: $${invoice.total.toFixed(2)}\nPaid: $${invoice.paidAmount.toFixed(2)}\nBalance Due: $${invoice.dueAmount.toFixed(2)}\nStatus: ${invoice.status.toUpperCase()}\n\nThank you for choosing ${cName}.`;

  // Helper to obtain html2canvas & jsPDF from CDN (window) or fallback imported package
  const getRenderLibraries = async () => {
    // 1. html2canvas from window CDN or package
    let h2c: any = (window as any).html2canvas;
    if (!h2c) {
      h2c = html2canvasPackage;
    }

    // 2. jsPDF from window CDN or package
    let jsPDFConstructor: any = (window as any).jspdf?.jsPDF || (window as any).jsPDF;
    if (!jsPDFConstructor) {
      jsPDFConstructor = jsPDFPackage;
    }

    if (!h2c || !jsPDFConstructor) {
      throw new Error('PDF rendering libraries could not be initialized.');
    }

    return { html2canvasLib: h2c, jsPDFLib: jsPDFConstructor };
  };

  // Generate multi-page A4 PDF using html2canvas and jsPDF (CDN/lib)
  const generateInvoicePdf = async (): Promise<{ pdf: any; blob: Blob }> => {
    const contentEl = printContentRef.current;
    if (!contentEl) {
      throw new Error('Invoice content element was not found in the DOM.');
    }

    const { html2canvasLib, jsPDFLib } = await getRenderLibraries();

    // Render canvas with high resolution, white background, CORS enabled
    const canvas = await html2canvasLib(contentEl, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: contentEl.scrollWidth || 800,
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.98);

    // Create A4 PDF (210mm x 297mm)
    const pdf = new jsPDFLib({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = pdf.internal.pageSize.getWidth(); // 210mm
    const pdfHeight = pdf.internal.pageSize.getHeight(); // 297mm
    const margin = 10; // 10mm margin
    const contentWidth = pdfWidth - margin * 2; // 190mm
    const totalImageHeight = (canvas.height * contentWidth) / canvas.width;
    const pageAvailableHeight = pdfHeight - margin * 2; // 277mm

    // Handle single-page or multi-page slice
    if (totalImageHeight <= pageAvailableHeight) {
      pdf.addImage(imgData, 'JPEG', margin, margin, contentWidth, totalImageHeight);
    } else {
      let heightLeft = totalImageHeight;
      let position = 0;

      // First page
      pdf.addImage(imgData, 'JPEG', margin, margin, contentWidth, totalImageHeight);
      heightLeft -= pageAvailableHeight;

      // Additional pages if content overflows A4
      while (heightLeft > 0) {
        position -= pageAvailableHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', margin, margin + position, contentWidth, totalImageHeight);
        heightLeft -= pageAvailableHeight;
      }
    }

    const blob = pdf.output('blob');
    return { pdf, blob };
  };

  // Download PDF handler with clear error reporting and retry
  const handleDownloadPdf = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setPdfError(null);
    setIsPdfGenerating(true);

    try {
      // Desktop app: save a real (text) PDF through Electron
      if (await savePageAsPdf(pdfFileName, printContentRef.current)) return;

      const { pdf, blob } = await generateInvoicePdf();

      // Reliable mobile Chrome & desktop download flow
      try {
        pdf.save(pdfFileName);
      } catch (saveErr) {
        // Fallback for strict mobile webview environments
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = pdfFileName;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
          document.body.removeChild(a);
          URL.revokeObjectURL(blobUrl);
        }, 1000);
      }
    } catch (err: any) {
      console.error('Invoice PDF download error:', err);
      setPdfError(
        err?.message || 'Failed to generate Invoice PDF. Please check your network or try again.'
      );
    } finally {
      setIsPdfGenerating(false);
    }
  };

  // Web Share API WhatsApp share with direct PDF File attachment, falling back to wa.me + download
  const handleWhatsAppShare = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setPdfError(null);
    setIsSharingWhatsApp(true);

    try {
      // phone app: the Share menu lists WhatsApp, send the PDF from there
      if (Capacitor.isNativePlatform()) {
        await savePageAsPdf(pdfFileName, printContentRef.current);
        return;
      }
      const cleanPhone = activePhone.replace(/[^0-9]/g, '');
      const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(whatsappMessage)}`;

      // Try generating file for Web Share API
      let file: File | null = null;
      try {
        const { blob } = await generateInvoicePdf();
        file = new File([blob], pdfFileName, { type: 'application/pdf' });
      } catch (genErr) {
        console.warn('PDF generation for WhatsApp share failed, proceeding with text:', genErr);
      }

      // Check if navigator.share and file sharing are supported
      if (
        file &&
        typeof navigator !== 'undefined' &&
        typeof navigator.share === 'function' &&
        typeof navigator.canShare === 'function' &&
        navigator.canShare({ files: [file] })
      ) {
        try {
          await navigator.share({
            files: [file],
            title: `Invoice ${safeInvoiceNo}`,
            text: whatsappMessage,
          });
          setIsSharingWhatsApp(false);
          return;
        } catch (shareErr: any) {
          // If user cancelled, don't show error
          if (shareErr.name === 'AbortError') {
            setIsSharingWhatsApp(false);
            return;
          }
          console.warn('navigator.share failed, using fallback:', shareErr);
        }
      }

      // Fallback: download PDF and open WhatsApp in a new tab
      if (file) {
        try {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(file);
          a.download = pdfFileName;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => {
            document.body.removeChild(a);
          }, 1000);
        } catch (dErr) {
          console.warn('Fallback file download error:', dErr);
        }
      }

      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch (err: any) {
      console.error('WhatsApp share error:', err);
      setPdfError('Could not share via WhatsApp. Please download the PDF and send manually.');
    } finally {
      setIsSharingWhatsApp(false);
    }
  };

  // Browser/device native print flow
  const handlePrint = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setPdfError(null);
    try {
      if (typeof window !== 'undefined' && typeof window.print === 'function') {
        await printPage(printContentRef.current, pdfFileName);
      } else {
        throw new Error('window.print is not supported in this browser.');
      }
    } catch (err: any) {
      console.error('Invoice print error:', err);
      setPdfError('Unable to open print preview. Please try Download PDF instead.');
    }
  };

  return (
    <div className="invoice-print-modal-overlay fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 print:p-0 print:bg-white print:fixed print:inset-0">
      <div className="invoice-print-modal-container bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[94vh] print:max-h-none print:shadow-none print:border-none print:rounded-none relative">
        
        {/* RESPONSIVE TOP ACTION BAR (Hidden during print) */}
        <div className="invoice-toolbar px-3 py-2.5 sm:px-5 sm:py-3 border-b border-slate-200 bg-slate-50/95 backdrop-blur-xs flex flex-wrap items-center justify-between gap-2 print:hidden sticky top-0 z-30 shrink-0">
          
          {/* Title & Invoice badge */}
          <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
            <Receipt className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="text-xs font-bold text-slate-800 whitespace-nowrap">Invoice:</span>
            <span className="font-mono text-xs font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 truncate">
              {safeInvoiceNo}
            </span>
          </div>

          {/* Action buttons (grid-cols-2 on screens under 640px, flex row on sm+) */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 w-full sm:w-auto justify-end">
            
            {/* WhatsApp Share Button */}
            {activePhone && (
              <button
                type="button"
                onClick={handleWhatsAppShare}
                disabled={isSharingWhatsApp}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-medium text-xs transition shadow-2xs cursor-pointer disabled:opacity-60"
                title="Share invoice PDF directly via WhatsApp"
              >
                {isSharingWhatsApp ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <MessageCircle className="w-3.5 h-3.5 fill-white text-emerald-500" />
                )}
                <span className="whitespace-nowrap">WhatsApp</span>
              </button>
            )}

            {/* Download PDF Button */}
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isPdfGenerating}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition cursor-pointer border border-slate-200 disabled:opacity-60"
              title="Download Invoice as A4 PDF"
            >
              {isPdfGenerating ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-600" />
              ) : (
                <FileDown className="w-3.5 h-3.5 text-slate-600" />
              )}
              <span className="whitespace-nowrap">{isPdfGenerating ? 'Rendering...' : 'Download PDF'}</span>
            </button>

            {/* Print Invoice Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              title="Print Tax Invoice (A4 Layout)"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="whitespace-nowrap">Print</span>
            </button>

            {/* Close [X] Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer border border-slate-200 sm:border-transparent shrink-0"
              title="Close Preview (Esc)"
              aria-label="Close Invoice Preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Clear error banner with Retry button if PDF generation fails */}
        {pdfError && (
          <div className="invoice-error-banner px-4 py-2.5 bg-rose-50 border-b border-rose-200 text-rose-700 text-xs font-medium flex items-center justify-between gap-3 print:hidden shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span className="truncate">{pdfError}</span>
            </div>
            <button
              type="button"
              onClick={handleDownloadPdf}
              className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shrink-0 cursor-pointer flex items-center gap-1 shadow-2xs"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry PDF</span>
            </button>
          </div>
        )}

        {/* PRINTABLE INVOICE SHEET (Scrolls inside container on mobile) */}
        <div
          ref={printContentRef}
          className="invoice-print-content p-4 sm:p-8 md:p-10 overflow-y-auto print:p-0 print:overflow-visible text-slate-900 font-sans space-y-6 bg-white"
        >
          {/* Header */}
          <div className="border-b-2 border-slate-900 pb-5 flex flex-col sm:flex-row items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center print:border print:border-slate-800">
                  <HeartPulse className="w-5 h-5 text-cyan-200 print:text-slate-900" />
                </div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight uppercase">
                  {cName}
                </h1>
              </div>
              <p className="text-xs text-slate-600 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                <span>{addr || 'Clinic Address & Location'}</span>
              </p>
              <p className="text-xs text-slate-600 flex items-center gap-1 mt-0.5">
                <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                <span>Phone / Billing: {phone || 'Not Specified'}</span>
              </p>
            </div>

            <div className="sm:text-right w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">TAX INVOICE</span>
              <h2 className="text-lg font-black font-mono text-slate-900">{safeInvoiceNo}</h2>
              <p className="text-xs text-slate-600">Date: {invoice.date}</p>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-full inline-block mt-1 uppercase border print:border-slate-400 ${
                  invoice.status === 'paid'
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                    : invoice.status === 'partial'
                    ? 'bg-amber-100 text-amber-800 border-amber-200'
                    : 'bg-rose-100 text-rose-800 border-rose-200'
                }`}
              >
                Status: {invoice.status}
              </span>
            </div>
          </div>

          {/* Patient Details */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Billed To</span>
              <span className="font-bold text-slate-900 text-sm">{invoice.patientName}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Patient ID</span>
              <span className="font-mono font-semibold text-slate-800">{invoice.patientId}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Attending Doctor</span>
              <span className="font-semibold text-slate-800">{docName}</span>
            </div>
          </div>

          {/* Horizontally scrolling table container on mobile */}
          <div className="border border-slate-200 rounded-xl overflow-x-auto print:overflow-visible print:border-slate-300">
            <table className="w-full min-w-[550px] sm:min-w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3 w-8">#</th>
                  <th className="py-2.5 px-3">Service / Medication Description</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3 text-right">Qty</th>
                  <th className="py-2.5 px-3 text-right">Unit Price</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoice.items.map((item, idx) => (
                  <tr key={item.id || idx}>
                    <td className="py-2.5 px-3 text-slate-400 font-bold">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">{item.description}</td>
                    <td className="py-2.5 px-3 text-slate-500 uppercase text-[10px]">{item.type}</td>
                    <td className="py-2.5 px-3 text-right font-mono">{item.quantity}</td>
                    <td className="py-2.5 px-3 text-right font-mono">${item.unitPrice.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                      ${item.amount.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Calculation summary */}
          <div className="flex justify-end pt-2 text-xs avoid-break invoice-summary-box">
            <div className="w-full sm:w-64 space-y-2 border border-slate-200 p-4 rounded-xl bg-slate-50/60 print:bg-transparent">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-mono font-semibold">${invoice.subtotal.toFixed(2)}</span>
              </div>
              {invoice.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Discount:</span>
                  <span className="font-mono font-semibold">-${invoice.discount.toFixed(2)}</span>
                </div>
              )}
              {invoice.tax > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Tax:</span>
                  <span className="font-mono font-semibold">+${invoice.tax.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-sm text-slate-900 pt-2 border-t border-slate-200">
                <span>Total Amount:</span>
                <span className="font-mono">${invoice.total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-emerald-700 font-semibold pt-1 border-t border-slate-200">
                <span>Amount Paid:</span>
                <span className="font-mono">${invoice.paidAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-rose-600 font-bold pt-1">
                <span>Balance Due:</span>
                <span className="font-mono">${invoice.dueAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Footer note */}
          <div className="pt-8 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 text-[11px] text-slate-500 avoid-break invoice-footer-box">
            <div>
              <p className="font-bold text-slate-700">Payment Terms & Notes:</p>
              <p>Thank you for choosing {cName}. Receipts valid for medical reimbursement.</p>
            </div>
            <div className="text-center w-full sm:w-40 pt-2 sm:pt-0">
              <div className="h-10 border-b border-slate-400 flex items-end justify-center pb-1">
                <span className="text-slate-400 italic">Clinic Accounts</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">Authorized Cashier / Reception</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
