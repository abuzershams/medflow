import React, { useState, useEffect } from 'react';
import { DesktopBackupPanel } from './DesktopBackupPanel';
import { MobileBackupPanel } from './MobileBackupPanel';
import { useAuth } from '../../context/AuthContext';
import { LogoutConfirmationModal } from '../common/LogoutConfirmationModal';
import { Clinic, AuditLog } from '../../types';
import {
  saveClinicInfo,
  updatePrintingSettings,
  subscribeAuditLogs,
  recordAudit,
  hashPassword,
} from '../../services/db';
import {
  Settings,
  Building2,
  Lock,
  Download,
  Upload,
  ShieldCheck,
  Save,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Clock,
  User,
  Activity,
  History,
  Printer,
  LogOut,
} from 'lucide-react';

interface SettingsViewProps {
  allDataForBackup?: {
    patients: any[];
    appointments: any[];
    consultations: any[];
    prescriptions: any[];
    medicines: any[];
    invoices: any[];
    payments: any[];
  };
}

export function SettingsView({ allDataForBackup }: SettingsViewProps) {
  const { clinic, currentUser, updatePassword, updateUsername, reloadClinic } = useAuth();
  const [activeTab, setActiveTab] = useState<'clinic' | 'printing' | 'security' | 'backup' | 'audit'>('clinic');
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  // Clinic profile form
  const [clinicName, setClinicName] = useState(clinic?.name || '');
  const [doctorName, setDoctorName] = useState(clinic?.doctorName || '');
  const [qualification, setQualification] = useState(clinic?.qualification || '');
  const [registrationNumber, setRegistrationNumber] = useState(clinic?.registrationNumber || '');
  const [phone, setPhone] = useState(clinic?.phone || '');
  const [whatsapp, setWhatsapp] = useState(clinic?.whatsapp || '');
  const [email, setEmail] = useState(clinic?.email || '');
  const [address, setAddress] = useState(clinic?.address || '');
  const [workingHours, setWorkingHours] = useState(clinic?.workingHours || '');
  const [logoUrl, setLogoUrl] = useState(clinic?.logoUrl || '');
  const [autoPrintOnSave, setAutoPrintOnSave] = useState(clinic?.autoPrintOnSave ?? false);
  const [autoPrintPrescription, setAutoPrintPrescription] = useState(clinic?.autoPrintPrescription ?? false);
  const [autoPrintInvoice, setAutoPrintInvoice] = useState(clinic?.autoPrintInvoice ?? false);

  const [clinicSaved, setClinicSaved] = useState(false);
  const [clinicError, setClinicError] = useState('');
  const [isSavingClinic, setIsSavingClinic] = useState(false);

  // Printing settings feedback
  const [printingSaved, setPrintingSaved] = useState(false);
  const [printingError, setPrintingError] = useState('');
  const [isSavingPrinting, setIsSavingPrinting] = useState(false);

  // Username Change Form
  const [newUsername, setNewUsername] = useState('');
  const [confirmUsername, setConfirmUsername] = useState('');
  const [usernamePassword, setUsernamePassword] = useState('');
  const [showUsernamePassword, setShowUsernamePassword] = useState(false);
  const [usernameSaved, setUsernameSaved] = useState(false);
  const [usernameError, setUsernameError] = useState('');
  const [isSavingUsername, setIsSavingUsername] = useState(false);

  // Password Change Form
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [passwordSaved, setPasswordSaved] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [isSavingPassword, setIsSavingPassword] = useState(false);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  useEffect(() => {
    if (clinic) {
      setClinicName(clinic.name || '');
      setDoctorName(clinic.doctorName || '');
      setQualification(clinic.qualification || '');
      setRegistrationNumber(clinic.registrationNumber || '');
      setPhone(clinic.phone || '');
      setWhatsapp(clinic.whatsapp || '');
      setEmail(clinic.email || '');
      setAddress(clinic.address || '');
      setWorkingHours(clinic.workingHours || '');
      setLogoUrl(clinic.logoUrl || '');
      setAutoPrintOnSave(clinic.autoPrintOnSave ?? false);
      setAutoPrintPrescription(clinic.autoPrintPrescription ?? false);
      setAutoPrintInvoice(clinic.autoPrintInvoice ?? false);
    }
  }, [clinic]);

  useEffect(() => {
    const unsub = subscribeAuditLogs((logs) => {
      setAuditLogs(logs);
    });
    return () => unsub();
  }, []);

  const handleClinicSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clinicName.trim() || !doctorName.trim()) {
      setClinicError('Clinic name and Doctor name are required');
      return;
    }

    setIsSavingClinic(true);
    setClinicError('');
    setClinicSaved(false);

    try {
      await saveClinicInfo({
        name: clinicName.trim(),
        doctorName: doctorName.trim(),
        qualification: qualification.trim(),
        registrationNumber: registrationNumber.trim(),
        phone: phone.trim(),
        whatsapp: whatsapp.trim() || phone.trim(),
        email: email.trim(),
        address: address.trim(),
        workingHours: workingHours.trim(),
        logoUrl: logoUrl.trim(),
        autoPrintOnSave,
        autoPrintPrescription,
        autoPrintInvoice,
      });

      await recordAudit(
        'Update Clinic Settings',
        `Updated clinic profile for ${clinicName}`,
        currentUser?.fullName || 'Staff',
        currentUser?.role || 'admin',
        'clinic'
      );

      setClinicSaved(true);
      reloadClinic();
      setTimeout(() => setClinicSaved(false), 3000);
    } catch (err: any) {
      setClinicError(err.message || 'Failed to save settings');
    } finally {
      setIsSavingClinic(false);
    }
  };

  const handlePrintingSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingPrinting(true);
    setPrintingError('');
    setPrintingSaved(false);

    try {
      await updatePrintingSettings({
        autoPrintOnSave,
        autoPrintPrescription,
        autoPrintInvoice,
      });

      await recordAudit(
        'Update Printing Settings',
        `Auto-print on save set to ${autoPrintOnSave ? 'Enabled' : 'Disabled'} (Rx: ${autoPrintPrescription ? 'Yes' : 'No'}, Invoice: ${autoPrintInvoice ? 'Yes' : 'No'})`,
        currentUser?.fullName || 'Staff',
        currentUser?.role || 'admin',
        'clinic'
      );

      setPrintingSaved(true);
      await reloadClinic();
      setTimeout(() => setPrintingSaved(false), 3000);
    } catch (err: any) {
      setPrintingError(err.message || 'Failed to update printing settings');
    } finally {
      setIsSavingPrinting(false);
    }
  };

  const handleUsernameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUsernameError('');
    setUsernameSaved(false);

    const cleanNew = newUsername.trim().toLowerCase().replace(/^@/, '');
    const cleanConfirm = confirmUsername.trim().toLowerCase().replace(/^@/, '');

    if (cleanNew.length < 3) {
      setUsernameError('New username must be at least 3 characters long');
      return;
    }

    if (!/^[a-zA-Z0-9_]+$/.test(cleanNew)) {
      setUsernameError('Username can only contain alphanumeric characters and underscores');
      return;
    }

    if (cleanNew !== cleanConfirm) {
      setUsernameError('New usernames do not match');
      return;
    }

    if (cleanNew === currentUser?.username.toLowerCase()) {
      setUsernameError('New username must be different from current username');
      return;
    }

    setIsSavingUsername(true);
    try {
      const res = await updateUsername(usernamePassword, cleanNew);
      if (!res.success) {
        setUsernameError(res.error || 'Failed to update username');
      } else {
        setUsernameSaved(true);
        setNewUsername('');
        setConfirmUsername('');
        setUsernamePassword('');
        setTimeout(() => setUsernameSaved(false), 4000);
      }
    } catch (err: any) {
      setUsernameError(err.message || 'Failed to update username');
    } finally {
      setIsSavingUsername(false);
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSaved(false);

    if (newPassword.length < 6) {
      setPasswordError('New password must be at least 6 characters');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match');
      return;
    }

    setIsSavingPassword(true);
    try {
      await updatePassword(currentPassword, newPassword);
      setPasswordSaved(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordSaved(false), 4000);
    } catch (err: any) {
      setPasswordError(err.message || 'Failed to update password');
    } finally {
      setIsSavingPassword(false);
    }
  };

  const handleDownloadBackup = () => {
    const backupData = {
      exportTimestamp: new Date().toISOString(),
      clinic,
      ...allDataForBackup,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute('href', dataStr);
    dlAnchorElem.setAttribute(
      'download',
      `medflow_backup_${new Date().toISOString().split('T')[0]}.json`
    );
    dlAnchorElem.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <Settings className="w-7 h-7 text-teal-600" />
          Clinic Configuration & Settings
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Configure clinic branding, user security, offline JSON backup, and system audit logs
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-6">
        <button
          onClick={() => setActiveTab('clinic')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 transition cursor-pointer border-b-2 -mb-px ${
            activeTab === 'clinic'
              ? 'border-teal-600 text-teal-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Building2 className="w-4 h-4" />
          Clinic Profile & Prescription Header
        </button>

        <button
          onClick={() => setActiveTab('printing')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 transition cursor-pointer border-b-2 -mb-px ${
            activeTab === 'printing'
              ? 'border-teal-600 text-teal-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Printer className="w-4 h-4" />
          Printing
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 transition cursor-pointer border-b-2 -mb-px ${
            activeTab === 'security'
              ? 'border-teal-600 text-teal-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Lock className="w-4 h-4" />
          Security & Password
        </button>

        <button
          onClick={() => setActiveTab('backup')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 transition cursor-pointer border-b-2 -mb-px ${
            activeTab === 'backup'
              ? 'border-teal-600 text-teal-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Download className="w-4 h-4" />
          Data Backup & Export
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 transition cursor-pointer border-b-2 -mb-px ${
            activeTab === 'audit'
              ? 'border-teal-600 text-teal-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          Activity & Audit Trail
        </button>
      </div>

      {/* TAB 1: CLINIC PROFILE */}
      {activeTab === 'clinic' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs max-w-4xl">
          <form onSubmit={handleClinicSubmit} className="space-y-6">
            {clinicSaved && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-emerald-700 text-sm">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                Clinic settings saved successfully.
              </div>
            )}
            {clinicError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-sm">
                <AlertCircle className="w-5 h-5 shrink-0" />
                {clinicError}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Clinic / Hospital Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={clinicName}
                  onChange={(e) => setClinicName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Chief Doctor Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Doctor Qualifications
                </label>
                <input
                  type="text"
                  placeholder="e.g. MBBS, MD (General Medicine)"
                  value={qualification}
                  onChange={(e) => setQualification(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Medical Registration Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. REG-123456 / NMC-987"
                  value={registrationNumber}
                  onChange={(e) => setRegistrationNumber(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Primary Clinic Phone
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  WhatsApp Number (For Patient Reminders)
                </label>
                <input
                  type="tel"
                  placeholder="+1-555-0192"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Clinic Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Working Hours / Timings
                </label>
                <input
                  type="text"
                  placeholder="Mon-Sat: 09:00 AM - 08:00 PM"
                  value={workingHours}
                  onChange={(e) => setWorkingHours(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Physical Address
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Clinic Logo (URL or Web link)
                </label>
                <input
                  type="url"
                  placeholder="https://example.com/clinic-logo.png"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              {/* Printing & Workflow Automation Settings */}
              <div className="md:col-span-2 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Printer className="w-4 h-4 text-teal-600" />
                    Printing & Slip Automation
                  </h4>
                  <button
                    type="button"
                    onClick={() => setActiveTab('printing')}
                    className="text-xs text-teal-600 hover:text-teal-700 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    Open Advanced Printing Tab →
                  </button>
                </div>
                
                <div className="space-y-3">
                  {/* Master Auto-print on save */}
                  <label className="flex items-start gap-3.5 p-3.5 rounded-xl border border-teal-200 bg-teal-50/40 hover:bg-teal-50/70 cursor-pointer transition">
                    <input
                      type="checkbox"
                      checked={autoPrintOnSave}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setAutoPrintOnSave(checked);
                        if (checked) {
                          setAutoPrintPrescription(true);
                          setAutoPrintInvoice(true);
                        }
                      }}
                      className="mt-0.5 w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                    />
                    <div className="space-y-0.5">
                      <span className="text-sm font-bold text-slate-900 flex items-center gap-2">
                        Auto-print on save
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-teal-600 text-white">
                          Master
                        </span>
                      </span>
                      <p className="text-xs text-slate-600">
                        Automatically pop open the printable modal preview immediately whenever a prescription or invoice is saved.
                      </p>
                    </div>
                  </label>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    {/* Prescription Auto-print */}
                    <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 hover:border-teal-300 bg-slate-50/50 cursor-pointer transition">
                      <input
                        type="checkbox"
                        checked={autoPrintPrescription}
                        onChange={(e) => setAutoPrintPrescription(e.target.checked)}
                        className="mt-0.5 w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                      />
                      <div className="space-y-0.5">
                        <span className="text-xs font-semibold text-slate-900 block">
                          Auto-print Prescriptions
                        </span>
                        <p className="text-[11px] text-slate-500">
                          Pop open Rx slip print dialog when saved.
                        </p>
                      </div>
                    </label>

                    {/* Invoice Auto-print */}
                    <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 hover:border-teal-300 bg-slate-50/50 cursor-pointer transition">
                      <input
                        type="checkbox"
                        checked={autoPrintInvoice}
                        onChange={(e) => setAutoPrintInvoice(e.target.checked)}
                        className="mt-0.5 w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                      />
                      <div className="space-y-0.5">
                        <span className="text-xs font-semibold text-slate-900 block">
                          Auto-print Invoices
                        </span>
                        <p className="text-[11px] text-slate-500">
                          Pop open receipt print modal upon creation.
                        </p>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                disabled={isSavingClinic}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-medium transition shadow-xs cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {isSavingClinic ? 'Saving Changes...' : 'Save Clinic Profile'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB: PRINTING */}
      {activeTab === 'printing' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs max-w-4xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                <Printer className="w-5 h-5 text-teal-600" />
                Printing & Slip Automation
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Configure automatic print dialog triggers when saving prescriptions and billing invoices.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span
                className={`text-xs px-2.5 py-1 rounded-full font-semibold border ${
                  autoPrintOnSave
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-slate-100 text-slate-600 border-slate-200'
                }`}
              >
                {autoPrintOnSave ? 'Auto-print: Active' : 'Auto-print: Off'}
              </span>
            </div>
          </div>

          {printingSaved && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2.5 text-emerald-700 text-sm">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              Printing preferences saved persistently to database! Auto-print is active.
            </div>
          )}

          {printingError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2.5 text-rose-700 text-sm">
              <AlertCircle className="w-5 h-5 shrink-0" />
              {printingError}
            </div>
          )}

          <form onSubmit={handlePrintingSubmit} className="space-y-6">
            {/* Primary Setting: Auto-print on save */}
            <div className="p-5 rounded-2xl border-2 border-teal-500/30 bg-teal-50/40 hover:bg-teal-50/60 transition shadow-xs">
              <label className="flex items-start gap-4 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoPrintOnSave}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setAutoPrintOnSave(checked);
                    if (checked) {
                      setAutoPrintPrescription(true);
                      setAutoPrintInvoice(true);
                    }
                  }}
                  className="mt-1 w-5 h-5 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-slate-900">
                      Auto-print on save
                    </span>
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-teal-600 text-white">
                      Recommended
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    When enabled, saving a digital prescription or creating an invoice immediately opens the print preview dialog, so clinic staff and doctors can print or download PDFs without extra clicks.
                  </p>
                </div>
              </label>
            </div>

            {/* Granular Module Options */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Document Specific Preferences
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Prescription Option */}
                <label className="flex items-start gap-3.5 p-4 rounded-xl border border-slate-200 hover:border-teal-300 bg-white cursor-pointer transition shadow-xs">
                  <input
                    type="checkbox"
                    checked={autoPrintPrescription}
                    onChange={(e) => setAutoPrintPrescription(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                  />
                  <div className="space-y-1">
                    <span className="text-sm font-semibold text-slate-900 block">
                      Auto-print Prescriptions on Save
                    </span>
                    <p className="text-xs text-slate-500 leading-normal">
                      Triggers the Rx slip print window with clinic letterhead, doctor credentials, and patient diagnosis when saved.
                    </p>
                  </div>
                </label>

                {/* Invoice Option */}
                <label className="flex items-start gap-3.5 p-4 rounded-xl border border-slate-200 hover:border-teal-300 bg-white cursor-pointer transition shadow-xs">
                  <input
                    type="checkbox"
                    checked={autoPrintInvoice}
                    onChange={(e) => setAutoPrintInvoice(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500 cursor-pointer"
                  />
                  <div className="space-y-1">
                    <span className="text-sm font-semibold text-slate-900 block">
                      Auto-print Invoices on Save
                    </span>
                    <p className="text-xs text-slate-500 leading-normal">
                      Triggers the receipt slip print modal with itemized consultation, medicine charges, and payment balance upon generation.
                    </p>
                  </div>
                </label>
              </div>
            </div>

            {/* Clinical Workflow Explanation */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 space-y-2">
              <div className="flex items-center gap-2 font-semibold text-slate-800">
                <Activity className="w-4 h-4 text-teal-600" />
                <span>How Auto-print Works in Clinic Workflow</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-500 ml-1">
                <li>
                  <strong className="text-slate-700">Prescriptions:</strong> In Consultation & Prescriptions views, saving a record opens the professional Rx slip ready to print.
                </li>
                <li>
                  <strong className="text-slate-700">Invoices:</strong> In Billing & Invoices view, generating a bill or payment opens the receipt slip instantly.
                </li>
                <li>
                  Preference is saved persistently in the database and loaded automatically by the application.
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="submit"
                disabled={isSavingPrinting}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-medium transition shadow-xs cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {isSavingPrinting ? 'Saving Preferences...' : 'Save Printing Preferences'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 2: SECURITY & PASSWORD */}
      {activeTab === 'security' && (
        <div className="space-y-6 max-w-xl">
          {/* Change Username Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <div className="mb-6">
              <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                <User className="w-5 h-5 text-teal-600" />
                Change Username
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Current username: <strong className="text-teal-700 font-mono bg-teal-50 px-2 py-0.5 rounded border border-teal-200">@{currentUser?.username}</strong>
              </p>
            </div>

            {usernameSaved && (
              <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-emerald-700 text-sm">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                Username updated successfully! Please use @{currentUser?.username} for future logins.
              </div>
            )}
            {usernameError && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-sm">
                <AlertCircle className="w-5 h-5 shrink-0" />
                {usernameError}
              </div>
            )}

            <form onSubmit={handleUsernameSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  New Username <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">@</span>
                  <input
                    type="text"
                    required
                    placeholder="e.g. drchouhan_admin"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 rounded-lg border border-slate-200 text-sm font-mono focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Letters, numbers, and underscores only. Min 3 characters.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Confirm Username <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">@</span>
                  <input
                    type="text"
                    required
                    placeholder="Re-enter new username"
                    value={confirmUsername}
                    onChange={(e) => setConfirmUsername(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 rounded-lg border border-slate-200 text-sm font-mono focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Current Password (for authentication) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showUsernamePassword ? 'text' : 'password'}
                    required
                    placeholder="Enter your current password"
                    value={usernamePassword}
                    onChange={(e) => setUsernamePassword(e.target.value)}
                    className="w-full px-3 py-2 pr-10 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowUsernamePassword(!showUsernamePassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showUsernamePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isSavingUsername}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-medium transition shadow-xs cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  {isSavingUsername ? 'Updating...' : 'Update Username'}
                </button>
              </div>
            </form>
          </div>

          {/* Change Account Password Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <div className="mb-6">
              <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                <Lock className="w-5 h-5 text-teal-600" />
                Change Account Password
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Logged in as <strong className="text-slate-800">@{currentUser?.username}</strong> ({currentUser?.role})
              </p>
            </div>

          {passwordSaved && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-emerald-700 text-sm">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              Password updated successfully!
            </div>
          )}
          {passwordError && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-sm">
              <AlertCircle className="w-5 h-5 shrink-0" />
              {passwordError}
            </div>
          )}

          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Current Password <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type={showCurrent ? 'text' : 'password'}
                  required
                  placeholder="Enter current password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-3 py-2 pr-10 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrent(!showCurrent)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                New Password <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type={showNew ? 'text' : 'password'}
                  required
                  placeholder="Minimum 6 characters"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 pr-10 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowNew(!showNew)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Confirm New Password <span className="text-rose-500">*</span>
              </label>
              <input
                type="password"
                required
                placeholder="Re-enter new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                disabled={isSavingPassword}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-medium transition shadow-xs cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {isSavingPassword ? 'Updating...' : 'Update Password'}
              </button>
            </div>
          </form>
        </div>

        {/* Active Admin Session & Sign Out Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div className="space-y-0.5">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Active Admin Session
                </span>
                <p className="text-sm font-semibold text-slate-900">
                  {currentUser?.fullName} <span className="text-xs text-slate-500 font-normal">(@{currentUser?.username})</span>
                </p>
                <p className="text-xs text-slate-500">
                  Role: <span className="font-semibold text-purple-700 uppercase text-[10px] bg-purple-100 px-1.5 py-0.5 rounded border border-purple-200">{currentUser?.role}</span> • Clinic: {clinic?.name || 'MedFlow'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsLogoutModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold transition shadow-xs cursor-pointer shrink-0"
              >
                <LogOut className="w-4 h-4" />
                Log Out Admin
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: DATA BACKUP & EXPORT */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
        <DesktopBackupPanel />
        <MobileBackupPanel />
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs max-w-2xl space-y-6">
          <div>
            <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
              <Download className="w-5 h-5 text-teal-600" />
              Offline JSON Data Backup
            </h3>
            <p className="text-sm text-slate-500 mt-1">
              Download complete clinic records to an offline JSON file for safe record-keeping or migration.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2 text-xs text-slate-600">
            <p className="font-semibold text-slate-800">The backup file contains:</p>
            <ul className="list-disc list-inside space-y-1 text-slate-600">
              <li>Patient registries and personal demographics</li>
              <li>Appointment schedules and histories</li>
              <li>Clinical consultation notes, diagnoses, and medical histories</li>
              <li>Digital prescriptions and medicine regimens</li>
              <li>Medicine database, current stock levels, and supplier directory</li>
              <li>Billing invoices, itemized entries, and payment transactions</li>
            </ul>
          </div>

          <button
            onClick={handleDownloadBackup}
            className="inline-flex items-center gap-2 px-6 py-3 bg-teal-600 text-white rounded-xl hover:bg-teal-700 font-medium transition shadow-sm cursor-pointer"
          >
            <Download className="w-5 h-5" />
            Download Complete JSON Backup
          </button>
        </div>
        </div>
      )}

      {/* TAB 4: AUDIT TRAIL */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <History className="w-5 h-5 text-teal-600" />
                System Activity Audit Trail
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Detailed record of administrative, clinical, and billing events
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {auditLogs.length} Events Logged
            </span>
          </div>

          <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
            {auditLogs.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No audit events recorded yet.
              </div>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="p-4 hover:bg-slate-50 transition flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-slate-900 text-sm">{log.action}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700 uppercase">
                        {log.userRole}
                      </span>
                      {log.entityType && (
                        <span className="text-xs text-teal-600 font-medium">
                          [{log.entityType}]
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600">{log.details}</p>
                    <div className="text-[11px] text-slate-400 flex items-center gap-3">
                      <span>By: <strong className="text-slate-600">{log.performedBy}</strong></span>
                      <span>•</span>
                      <span>{new Date(log.timestamp).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Logout Confirmation Modal */}
      <LogoutConfirmationModal
        isOpen={isLogoutModalOpen}
        onClose={() => setIsLogoutModalOpen(false)}
      />
    </div>
  );
}
