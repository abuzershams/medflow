import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initStore } from './local/firestore.ts';

const root = createRoot(document.getElementById('root')!);

initStore()
  .then(() => root.render(<App />))
  .catch((err) => {
    console.error('Failed to open local database', err);
    document.getElementById('root')!.innerHTML =
      '<div style="padding:24px;font-family:sans-serif"><h2>Database could not be opened</h2><p>' +
      String(err && err.message ? err.message : err) +
      '</p></div>';
  });
