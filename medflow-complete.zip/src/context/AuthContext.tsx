import React, { createContext, useContext, useState, useEffect } from 'react';
import { Clinic, UserStaff } from '../types';
import {
  getClinicInfo,
  hasAdminAccount,
  getStaffByUsername,
  verifyPassword,
  hashPassword,
  updateStaffUser,
  recordAudit,
  seedStarterMedicinesIfEmpty,
} from '../services/db';

interface AuthContextType {
  clinic: Clinic | null;
  currentUser: UserStaff | null;
  isSetupNeeded: boolean;
  isInitialSetupRequired: boolean;
  isLoading: boolean;
  login: (username: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  refreshClinic: () => Promise<void>;
  reloadClinic: () => Promise<void>;
  updateUserPassword: (currentPass: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  updatePassword: (currentPass: string, newPass: string) => Promise<{ success: boolean; error?: string }>;
  updateUsername: (currentPass: string, newUsername: string) => Promise<{ success: boolean; error?: string }>;
  checkInitialStatus: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [clinic, setClinic] = useState<Clinic | null>(null);
  const [currentUser, setCurrentUser] = useState<UserStaff | null>(null);
  const [isSetupNeeded, setIsSetupNeeded] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const checkInitialStatus = async () => {
    setIsLoading(true);
    try {
      const clinicData = await getClinicInfo();
      const hasAdmin = await hasAdminAccount();

      if (!clinicData || !hasAdmin || !clinicData.setupCompleted) {
        setIsSetupNeeded(true);
        setCurrentUser(null);
      } else {
        setClinic(clinicData);
        setIsSetupNeeded(false);

        // Check if there is saved session in localStorage/sessionStorage
        const savedUserId = localStorage.getItem('medflow_current_user_id') || sessionStorage.getItem('medflow_current_user_id');
        const savedUsername = localStorage.getItem('medflow_current_username') || sessionStorage.getItem('medflow_current_username');

        if (savedUsername) {
          const staffUser = await getStaffByUsername(savedUsername);
          if (staffUser && staffUser.status === 'active') {
            setCurrentUser(staffUser);
          } else {
            localStorage.removeItem('medflow_current_user_id');
            localStorage.removeItem('medflow_current_username');
            sessionStorage.removeItem('medflow_current_user_id');
            sessionStorage.removeItem('medflow_current_username');
            setCurrentUser(null);
          }
        }
      }
    } catch (err) {
      console.error('Error during initial status check:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkInitialStatus();
  }, []);

  const refreshClinic = async () => {
    const updated = await getClinicInfo();
    if (updated) setClinic(updated);
  };

  const login = async (username: string, password: string, rememberMe: boolean = true) => {
    try {
      const user = await getStaffByUsername(username);
      if (!user) {
        return { success: false, error: 'Invalid username or password. Please try again.' };
      }

      if (user.status !== 'active') {
        return { success: false, error: 'This staff account has been deactivated. Contact clinic administrator.' };
      }

      const isValid = await verifyPassword(password, user.passwordHash);
      if (!isValid) {
        return { success: false, error: 'Invalid username or password. Please try again.' };
      }

      // Update last login
      await updateStaffUser(user.id, { lastLogin: new Date().toISOString() });

      const updatedUser = { ...user, lastLogin: new Date().toISOString() };
      setCurrentUser(updatedUser);

      const storage = rememberMe ? localStorage : sessionStorage;
      storage.setItem('medflow_current_user_id', user.id);
      storage.setItem('medflow_current_username', user.username);

      await recordAudit('LOGIN', `User ${user.username} logged into the system`, user.fullName, user.role, 'User', user.id);
      await seedStarterMedicinesIfEmpty();

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Login failed due to a server error.' };
    }
  };

  const logout = async () => {
    try {
      if (currentUser) {
        await recordAudit('LOGOUT', `User ${currentUser.username} logged out`, currentUser.fullName, currentUser.role);
      }
    } catch (err) {
      console.warn('Audit record on logout failed:', err);
    }

    try {
      // nothing else to clean up (offline build)
    } finally {
      localStorage.removeItem('medflow_current_user_id');
      localStorage.removeItem('medflow_current_username');
      sessionStorage.removeItem('medflow_current_user_id');
      sessionStorage.removeItem('medflow_current_username');
      setCurrentUser(null);

      // Prevent browser Back button from navigating to protected dashboard after logout
      try {
        window.history.pushState(null, '', window.location.href);
      } catch {
        // ignore iframe history restrictions if any
      }
    }
  };

  const updateUserPassword = async (currentPass: string, newPass: string) => {
    if (!currentUser) return { success: false, error: 'User is not logged in.' };

    try {
      const isValid = await verifyPassword(currentPass, currentUser.passwordHash);
      if (!isValid) {
        return { success: false, error: 'Current password is incorrect.' };
      }

      if (newPass.length < 6) {
        return { success: false, error: 'New password must be at least 6 characters long.' };
      }

      const newHash = await hashPassword(newPass);
      await updateStaffUser(currentUser.id, { passwordHash: newHash });
      setCurrentUser({ ...currentUser, passwordHash: newHash });

      await recordAudit(
        'CHANGE_PASSWORD',
        `Password changed for user ${currentUser.username}`,
        currentUser.fullName,
        currentUser.role
      );

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update password.' };
    }
  };

  const updateUsername = async (currentPass: string, newUsername: string) => {
    if (!currentUser) return { success: false, error: 'User is not logged in.' };

    const cleanUsername = newUsername.trim().toLowerCase().replace(/^@/, '');
    if (!cleanUsername || cleanUsername.length < 3) {
      return { success: false, error: 'Username must be at least 3 characters long.' };
    }

    if (!/^[a-zA-Z0-9_]+$/.test(cleanUsername)) {
      return { success: false, error: 'Username can only contain letters, numbers, and underscores.' };
    }

    if (cleanUsername === currentUser.username.toLowerCase()) {
      return { success: false, error: 'New username must be different from current username.' };
    }

    try {
      const isValid = await verifyPassword(currentPass, currentUser.passwordHash);
      if (!isValid) {
        return { success: false, error: 'Current password is incorrect.' };
      }

      // Check if username is already taken
      const existingUser = await getStaffByUsername(cleanUsername);
      if (existingUser && existingUser.id !== currentUser.id) {
        return { success: false, error: `Username @${cleanUsername} is already taken. Please choose another.` };
      }

      const oldUsername = currentUser.username;
      await updateStaffUser(currentUser.id, { username: cleanUsername });

      const updatedUser = { ...currentUser, username: cleanUsername };
      setCurrentUser(updatedUser);

      // Update stored session
      if (localStorage.getItem('medflow_current_username')) {
        localStorage.setItem('medflow_current_username', cleanUsername);
      }
      if (sessionStorage.getItem('medflow_current_username')) {
        sessionStorage.setItem('medflow_current_username', cleanUsername);
      }

      await recordAudit(
        'CHANGE_USERNAME',
        `Username updated from @${oldUsername} to @${cleanUsername} for ${currentUser.fullName}`,
        currentUser.fullName,
        currentUser.role
      );

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update username.' };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        clinic,
        currentUser,
        isSetupNeeded,
        isInitialSetupRequired: isSetupNeeded,
        isLoading,
        login,
        logout,
        refreshClinic,
        reloadClinic: refreshClinic,
        updateUserPassword,
        updatePassword: updateUserPassword,
        updateUsername,
        checkInitialStatus,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
