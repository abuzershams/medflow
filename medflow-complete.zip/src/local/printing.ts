/**
 * Printing helpers that work offline on every platform.
 *  - Desktop app (Electron): real Windows print dialog / "Save as PDF" file dialog.
 *  - Phone app (Capacitor/Android): makes a PDF and opens the Share menu
 *    (Print, WhatsApp, Drive, Save to Files ...), because phones have no window.print().
 *  - Normal browser: window.print() / jsPDF download.
 */
import { Capacitor } from '@capacitor/core';
import html2canvas from 'html2canvas-pro';
import jsPDF from 'jspdf';

const isPhoneApp = () => Capacitor.isNativePlatform();

async function elementToPdfBase64(el: HTMLElement): Promise<string> {
  const canvas = await html2canvas(el, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    windowWidth: 900, // lay out like a desktop page so the PDF looks like an A4 sheet
  });
  const img = canvas.toDataURL('image/jpeg', 0.95);
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const margin = 8;
  const w = pageW - margin * 2;
  const totalH = (canvas.height * w) / canvas.width;
  const availH = pageH - margin * 2;

  pdf.addImage(img, 'JPEG', margin, margin, w, totalH);
  let left = totalH - availH;
  let offset = 0;
  while (left > 0) {
    offset -= availH;
    pdf.addPage();
    pdf.addImage(img, 'JPEG', margin, margin + offset, w, totalH);
    left -= availH;
  }
  const dataUri = pdf.output('datauristring'); // data:application/pdf;filename=...;base64,XXXX
  return dataUri.substring(dataUri.indexOf('base64,') + 7);
}

async function sharePdfOnPhone(el: HTMLElement, fileName: string): Promise<void> {
  const { Filesystem, Directory } = await import('@capacitor/filesystem');
  const { Share } = await import('@capacitor/share');
  const data = await elementToPdfBase64(el);
  const safe = fileName.replace(/[^\w.\-]+/g, '_');
  const written = await Filesystem.writeFile({ path: safe, data, directory: Directory.Cache });
  await Share.share({ title: safe, url: written.uri, dialogTitle: 'Print / Save / Send PDF' });
}

/** Print button. `el` + `fileName` are needed for the phone app. */
export async function printPage(el?: HTMLElement | null, fileName = 'document.pdf'): Promise<void> {
  if (isPhoneApp()) {
    if (!el) throw new Error('Nothing to print here.');
    await sharePdfOnPhone(el, fileName);
    return;
  }
  const api = window.electronAPI;
  if (api?.printPage) {
    const r = await api.printPage();
    if (!r.ok && r.reason && !/cancel/i.test(r.reason)) {
      throw new Error('Print failed: ' + r.reason);
    }
    return;
  }
  window.print();
}

/**
 * "Download PDF" button. Returns true if it handled the job (desktop or phone app),
 * false if the caller should use its own browser download code.
 */
export async function savePageAsPdf(fileName: string, el?: HTMLElement | null): Promise<boolean> {
  if (isPhoneApp()) {
    if (!el) throw new Error('Nothing to save here.');
    await sharePdfOnPhone(el, fileName);
    return true;
  }
  const api = window.electronAPI;
  if (!api?.savePdf) return false;
  const r = await api.savePdf(fileName);
  if (!r.ok && !r.canceled) throw new Error(r.error || 'Could not save PDF');
  return true;
}
