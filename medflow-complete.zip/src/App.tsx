/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { InitialSetupView } from './components/auth/InitialSetupView';
import { LoginView } from './components/auth/LoginView';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';

// Modals
import { PatientFormModal } from './components/patients/PatientFormModal';
import { PatientProfileModal } from './components/patients/PatientProfileModal';
import { AppointmentFormModal } from './components/appointments/AppointmentFormModal';
import { VitalFormModal } from './components/vitals/VitalFormModal';
import { PrescriptionPrintModal } from './components/prescriptions/PrescriptionPrintModal';
import { InvoicePrintModal } from './components/billing/InvoicePrintModal';
import { ChangePasswordModal } from './components/settings/ChangePasswordModal';

// Views
import { DashboardView } from './components/dashboard/DashboardView';
import { PatientsView } from './components/patients/PatientsView';
import { AppointmentsView } from './components/appointments/AppointmentsView';
import { ConsultationView } from './components/consultation/ConsultationView';
import { VitalsView } from './components/vitals/VitalsView';
import { PrescriptionsView } from './components/prescriptions/PrescriptionsView';
import { MedicinesView } from './components/medicines/MedicinesView';
import { InventoryView } from './components/inventory/InventoryView';
import { SuppliersView } from './components/suppliers/SuppliersView';
import { BillingView } from './components/billing/BillingView';
import { DocumentsView } from './components/documents/DocumentsView';
import { FollowupsView } from './components/followups/FollowupsView';
import { ReportsView } from './components/reports/ReportsView';
import { StaffView } from './components/staff/StaffView';
import { SettingsView } from './components/settings/SettingsView';

// DB Services
import {
  subscribePatients,
  subscribeAppointments,
  subscribeVitals,
  subscribeConsultations,
  subscribePrescriptions,
  subscribeMedicines,
  subscribeStockMovements,
  subscribeSuppliers,
  subscribeInvoices,
  subscribePayments,
  subscribeMedicalDocuments,
  subscribeFollowUps,
  getAllStaff,
  addPatient,
  updatePatient,
  deletePatient,
  addAppointment,
  updateAppointment,
  deleteAppointment,
  addVital,
  addConsultation,
  addPrescription,
  addFollowUp,
  createInvoice,
  updateInvoicePayment,
  addSupplier,
  adjustMedicineStock,
} from './services/db';

import {
  Patient,
  Appointment,
  Vital,
  Consultation,
  Prescription,
  Medicine,
  StockMovement,
  Supplier,
  Invoice,
  Payment,
  MedicalDocument,
  FollowUp,
  UserStaff,
} from './types';
import { HeartPulse, Loader2 } from 'lucide-react';

function MainAppContent() {
  const { isLoading, isSetupNeeded, currentUser, clinic } = useAuth();

  // Navigation
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Real-time Database State
  const [patients, setPatients] = useState<Patient[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [vitals, setVitals] = useState<Vital[]>([]);
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [medicalDocuments, setMedicalDocuments] = useState<MedicalDocument[]>([]);
  const [followUps, setFollowUps] = useState<FollowUp[]>([]);
  const [staffList, setStaffList] = useState<UserStaff[]>([]);

  // Modals & Action States
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
  const [selectedPatientForEdit, setSelectedPatientForEdit] = useState<Patient | null>(null);

  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [appointmentToEdit, setAppointmentToEdit] = useState<Appointment | null>(null);
  const [prefilledPatientForAppt, setPrefilledPatientForAppt] = useState<Patient | null>(null);

  const [isVitalModalOpen, setIsVitalModalOpen] = useState(false);
  const [prefilledPatientForVital, setPrefilledPatientForVital] = useState<Patient | null>(null);

  const [selectedPatientProfile, setSelectedPatientProfile] = useState<Patient | null>(null);
  const [consultationPatient, setConsultationPatient] = useState<Patient | null>(null);
  const [consultationAppointment, setConsultationAppointment] = useState<Appointment | null>(null);

  const [prescriptionConsultation, setPrescriptionConsultation] = useState<Consultation | null>(null);
  const [prescriptionPatient, setPrescriptionPatient] = useState<Patient | null>(null);

  const [prescriptionForPrint, setPrescriptionForPrint] = useState<Prescription | null>(null);
  const [invoiceForPrint, setInvoiceForPrint] = useState<Invoice | null>(null);
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState(false);

  // Load Staff
  const reloadStaff = useCallback(async () => {
    try {
      const list = await getAllStaff();
      setStaffList(list);
    } catch (err) {
      console.error('Failed to load staff list:', err);
    }
  }, []);

  // Keyboard shortcut Ctrl+K / Cmd+K for global search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Real-time subscriptions when user is logged in
  useEffect(() => {
    if (!currentUser) return;

    reloadStaff();

    const unsubPatients = subscribePatients(setPatients);
    const unsubAppts = subscribeAppointments(setAppointments);
    const unsubVitals = subscribeVitals(setVitals);
    const unsubConsultations = subscribeConsultations(setConsultations);
    const unsubPrescriptions = subscribePrescriptions(setPrescriptions);
    const unsubMedicines = subscribeMedicines(setMedicines);
    const unsubStock = subscribeStockMovements(setStockMovements);
    const unsubSuppliers = subscribeSuppliers(setSuppliers);
    const unsubInvoices = subscribeInvoices(setInvoices);
    const unsubPayments = subscribePayments(setPayments);
    const unsubDocs = subscribeMedicalDocuments(null, setMedicalDocuments);
    const unsubFollowups = subscribeFollowUps(setFollowUps);

    return () => {
      unsubPatients();
      unsubAppts();
      unsubVitals();
      unsubConsultations();
      unsubPrescriptions();
      unsubMedicines();
      unsubStock();
      unsubSuppliers();
      unsubInvoices();
      unsubPayments();
      unsubDocs();
      unsubFollowups();
    };
  }, [currentUser, reloadStaff]);

  // Handle Quick Action from Header
  const handleQuickAction = (action: 'patient' | 'appointment' | 'consultation' | 'prescription' | 'invoice') => {
    switch (action) {
      case 'patient':
        setSelectedPatientForEdit(null);
        setIsPatientModalOpen(true);
        break;
      case 'appointment':
        setAppointmentToEdit(null);
        setPrefilledPatientForAppt(null);
        setIsAppointmentModalOpen(true);
        break;
      case 'consultation':
        setCurrentTab('consultation');
        break;
      case 'prescription':
        setCurrentTab('prescriptions');
        break;
      case 'invoice':
        setCurrentTab('billing');
        break;
    }
  };

  // Handler to start consultation directly from an appointment or patient
  const handleStartConsultation = (patient: Patient, appointment?: Appointment) => {
    setConsultationPatient(patient);
    setConsultationAppointment(appointment || null);
    setCurrentTab('consultation');
  };

  // Handler to schedule appointment for a specific patient
  const handleNewAppointmentForPatient = (patient: Patient) => {
    setAppointmentToEdit(null);
    setPrefilledPatientForAppt(patient);
    setIsAppointmentModalOpen(true);
  };

  // Handler to record vitals for a specific patient
  const handleNewVitalForPatient = (patient: Patient) => {
    setPrefilledPatientForVital(patient);
    setIsVitalModalOpen(true);
  };

  // Low stock & today appts counters for header alerts
  const todayStr = new Date().toISOString().split('T')[0];
  const lowStockCount = medicines.filter((m) => m.currentStock <= m.minStockLevel).length;
  const todayAppointmentsCount = appointments.filter((a) => a.date === todayStr && a.status !== 'cancelled').length;

  // 1. Loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center text-white">
        <div className="relative flex items-center justify-center mb-6">
          <div className="w-20 h-20 rounded-2xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center animate-pulse">
            <HeartPulse className="w-10 h-10 text-teal-400 animate-bounce" />
          </div>
        </div>
        <h2 className="text-xl font-bold tracking-tight">MedFlow Clinic Management</h2>
        <p className="text-slate-400 text-sm mt-2 flex items-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin text-teal-400" />
          Connecting to clinic database...
        </p>
      </div>
    );
  }

  // 2. Initial Setup Screen (shown ONLY if no admin exists)
  if (isSetupNeeded) {
    return <InitialSetupView />;
  }

  // 3. Login Screen (required every time)
  if (!currentUser) {
    return <LoginView />;
  }

  // 4. Main Protected Medical SaaS Dashboard
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased">
      {/* Top Header */}
      <Header
        onToggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        onOpenGlobalSearch={() => setIsSearchOpen(true)}
        onQuickAction={handleQuickAction}
        lowStockCount={lowStockCount}
        todayAppointmentsCount={todayAppointmentsCount}
        onNavigateTab={(tab: string) => setCurrentTab(tab)}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Left Navigation Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={(tab: string) => {
            setCurrentTab(tab);
            setIsMobileSidebarOpen(false);
          }}
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {currentTab === 'dashboard' && (
            <DashboardView
              patients={patients}
              appointments={appointments}
              consultations={consultations}
              prescriptions={prescriptions}
              invoices={invoices}
              medicines={medicines}
              followUps={followUps}
              onNavigateTab={(tab: string) => setCurrentTab(tab)}
              onQuickAction={handleQuickAction}
              onStartConsultationForAppointment={(apt: Appointment) => {
                const patient = patients.find((p) => p.id === apt.patientId);
                if (patient) {
                  handleStartConsultation(patient, apt);
                }
              }}
              onSelectPatient={(p: Patient) => setSelectedPatientProfile(p)}
            />
          )}

          {currentTab === 'patients' && (
            <PatientsView
              patients={patients}
              onOpenAddModal={() => {
                setSelectedPatientForEdit(null);
                setIsPatientModalOpen(true);
              }}
              onOpenEditModal={(p: Patient) => {
                setSelectedPatientForEdit(p);
                setIsPatientModalOpen(true);
              }}
              onOpenProfileModal={(p: Patient) => setSelectedPatientProfile(p)}
              onOpenConsultation={(p: Patient) => handleStartConsultation(p)}
              onDeletePatient={async (id: string) => {
                await deletePatient(id);
              }}
            />
          )}

          {currentTab === 'appointments' && (
            <AppointmentsView
              appointments={appointments}
              onOpenBookModal={() => {
                setAppointmentToEdit(null);
                setPrefilledPatientForAppt(null);
                setIsAppointmentModalOpen(true);
              }}
              onOpenEditModal={(apt: Appointment) => {
                setAppointmentToEdit(apt);
                setIsAppointmentModalOpen(true);
              }}
              onStartConsultation={(apt: Appointment) => {
                const patient = patients.find((p) => p.id === apt.patientId);
                if (patient) {
                  handleStartConsultation(patient, apt);
                }
              }}
              onUpdateStatus={async (id, newStatus) => {
                await updateAppointment(id, { status: newStatus });
              }}
              onDeleteAppointment={async (id) => {
                await deleteAppointment(id);
              }}
            />
          )}

          {currentTab === 'consultation' && (
            <ConsultationView
              patients={patients}
              consultations={consultations}
              vitals={vitals}
              activePatient={consultationPatient}
              activeAppointment={consultationAppointment}
              doctorName={clinic?.doctorName || currentUser?.fullName || 'Dr. Doctor'}
              onSaveConsultation={async (data) => {
                const c = await addConsultation(data);
                // If a followUpDate was scheduled, automatically insert into FollowupsView
                if (data.followUpDate) {
                  try {
                    const pat = patients.find((p) => p.id === data.patientId);
                    await addFollowUp({
                      patientId: data.patientId,
                      patientName: data.patientName,
                      patientPhone: pat?.phone || '',
                      doctorName: data.doctorName,
                      scheduledDate: data.followUpDate,
                      reason: `Consultation review: ${data.diagnosis}`,
                      status: 'scheduled',
                      notes: data.advice || `Chief Complaint: ${data.chiefComplaint}`,
                    });
                  } catch (e) {
                    console.error('Failed to auto-create follow-up from consultation:', e);
                  }
                }
                return c;
              }}
              onProceedToPrescription={(c: Consultation, p: Patient) => {
                setPrescriptionConsultation(c);
                setPrescriptionPatient(p);
                setCurrentTab('prescriptions');
              }}
              onProceedToInvoice={(_c: Consultation, p: Patient) => {
                setSelectedPatientProfile(p);
                setCurrentTab('billing');
              }}
            />
          )}

          {currentTab === 'vitals' && (
            <VitalsView
              vitals={vitals}
              patients={patients}
              onOpenRecordModal={() => {
                setPrefilledPatientForVital(null);
                setIsVitalModalOpen(true);
              }}
              onSelectPatient={(p: Patient) => setSelectedPatientProfile(p)}
            />
          )}

          {currentTab === 'prescriptions' && (
            <PrescriptionsView
              prescriptions={prescriptions}
              patients={patients}
              medicines={medicines}
              doctorName={clinic?.doctorName || currentUser?.fullName || 'Dr. Doctor'}
              qualification={clinic?.qualification || 'MBBS, MD'}
              registrationNumber={clinic?.registrationNumber || 'REG-12345'}
              onSavePrescription={async (data) => {
                const rx = await addPrescription(data);
                // If a followUpDate was scheduled, automatically insert into FollowupsView
                if (data.followUpDate) {
                  try {
                    const pat = patients.find((p) => p.id === data.patientId);
                    await addFollowUp({
                      patientId: data.patientId,
                      patientName: data.patientName,
                      patientPhone: pat?.phone || '',
                      doctorName: data.doctorName,
                      scheduledDate: data.followUpDate,
                      reason: `Medication review: ${data.diagnosis}`,
                      status: 'scheduled',
                      notes: data.advice || `${data.medicines.length} medicines prescribed`,
                    });
                  } catch (e) {
                    console.error('Failed to auto-create follow-up from prescription:', e);
                  }
                }
                return rx;
              }}
              onOpenPrintModal={(rx: Prescription) => setPrescriptionForPrint(rx)}
              initialConsultation={prescriptionConsultation}
              initialPatient={prescriptionPatient}
            />
          )}

          {currentTab === 'medicines' && <MedicinesView medicines={medicines} />}

          {currentTab === 'inventory' && (
            <InventoryView
              medicines={medicines}
              movements={stockMovements}
              suppliers={suppliers}
              userName={currentUser?.fullName || 'Staff'}
              onAdjustStock={adjustMedicineStock}
            />
          )}

          {currentTab === 'suppliers' && (
            <SuppliersView
              suppliers={suppliers}
              onAddSupplier={async (data) => {
                const s = await addSupplier(data);
                return s;
              }}
            />
          )}

          {currentTab === 'billing' && (
            <BillingView
              invoices={invoices}
              patients={patients}
              onOpenPrintModal={(inv: Invoice) => setInvoiceForPrint(inv)}
              onCreateInvoice={async (data) => {
                const inv = await createInvoice(data);
                return inv;
              }}
              onUpdateInvoicePayment={updateInvoicePayment}
              userName={currentUser?.fullName || 'Staff'}
            />
          )}

          {currentTab === 'documents' && (
            <DocumentsView
              documents={medicalDocuments}
              patients={patients}
              onSelectPatient={(p: Patient) => setSelectedPatientProfile(p)}
            />
          )}

          {currentTab === 'followups' && (
            <FollowupsView
              followUps={followUps}
              patients={patients}
              onSelectPatient={(p: Patient) => setSelectedPatientProfile(p)}
              onNewConsultation={(p: Patient) => handleStartConsultation(p)}
            />
          )}

          {currentTab === 'reports' && (
            <ReportsView
              patients={patients}
              appointments={appointments}
              consultations={consultations}
              prescriptions={prescriptions}
              invoices={invoices}
              payments={payments}
              medicines={medicines}
            />
          )}

          {currentTab === 'staff' && (
            <StaffView staffList={staffList} onReloadStaff={reloadStaff} />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              allDataForBackup={{
                patients,
                appointments,
                consultations,
                prescriptions,
                medicines,
                invoices,
                payments,
              }}
            />
          )}
        </main>
      </div>

      {/* Global Search Modal (Ctrl+K) */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        patients={patients}
        appointments={appointments}
        prescriptions={prescriptions}
        invoices={invoices}
        onSelectResult={(type, item) => {
          setIsSearchOpen(false);
          if (type === 'patient') {
            setSelectedPatientProfile(item as Patient);
          } else if (type === 'appointment') {
            setCurrentTab('appointments');
          } else if (type === 'prescription') {
            setPrescriptionForPrint(item as Prescription);
          } else if (type === 'invoice') {
            setInvoiceForPrint(item as Invoice);
          }
        }}
      />

      {/* Patient Create / Edit Modal */}
      <PatientFormModal
        isOpen={isPatientModalOpen}
        onClose={() => setIsPatientModalOpen(false)}
        onSave={async (patientData) => {
          if (selectedPatientForEdit) {
            await updatePatient(selectedPatientForEdit.id, patientData);
          } else {
            await addPatient(patientData);
          }
          setIsPatientModalOpen(false);
        }}
        patientToEdit={selectedPatientForEdit}
      />

      {/* Appointment Create Modal */}
      <AppointmentFormModal
        isOpen={isAppointmentModalOpen}
        onClose={() => {
          setIsAppointmentModalOpen(false);
          setAppointmentToEdit(null);
          setPrefilledPatientForAppt(null);
        }}
        patients={patients}
        defaultDoctorName={clinic?.doctorName || currentUser?.fullName || 'Dr. Doctor'}
        onSave={async (data) => {
          if (appointmentToEdit) {
            await updateAppointment(appointmentToEdit.id, data);
          } else {
            await addAppointment(data);
          }
          setIsAppointmentModalOpen(false);
        }}
        appointmentToEdit={appointmentToEdit}
        preselectedPatient={prefilledPatientForAppt}
      />

      {/* Vital Record Modal */}
      <VitalFormModal
        isOpen={isVitalModalOpen}
        onClose={() => {
          setIsVitalModalOpen(false);
          setPrefilledPatientForVital(null);
        }}
        patients={patients}
        recordedBy={currentUser?.fullName || 'Nurse'}
        onSave={async (data) => {
          await addVital(data);
          setIsVitalModalOpen(false);
        }}
        preselectedPatient={prefilledPatientForVital}
      />

      {/* Patient Profile Modal */}
      {selectedPatientProfile && (
        <PatientProfileModal
          isOpen={!!selectedPatientProfile}
          onClose={() => setSelectedPatientProfile(null)}
          patient={selectedPatientProfile}
          appointments={appointments.filter((a) => a.patientId === selectedPatientProfile.id)}
          vitals={vitals.filter((v) => v.patientId === selectedPatientProfile.id)}
          consultations={consultations.filter((c) => c.patientId === selectedPatientProfile.id)}
          prescriptions={prescriptions.filter((p) => p.patientId === selectedPatientProfile.id)}
          invoices={invoices.filter((i) => i.patientId === selectedPatientProfile.id)}
          payments={payments.filter((p) => p.patientId === selectedPatientProfile.id)}
          documents={medicalDocuments.filter((d) => d.patientId === selectedPatientProfile.id)}
          followUps={followUps.filter((f) => f.patientId === selectedPatientProfile.id)}
          onOpenConsultation={(p: Patient) => {
            setSelectedPatientProfile(null);
            handleStartConsultation(p);
          }}
          onOpenPrescriptionPrint={(rx: Prescription) => setPrescriptionForPrint(rx)}
          onOpenInvoicePrint={(inv: Invoice) => setInvoiceForPrint(inv)}
        />
      )}

      {/* Prescription Print Slip Modal */}
      <PrescriptionPrintModal
        isOpen={!!prescriptionForPrint}
        onClose={() => setPrescriptionForPrint(null)}
        prescription={prescriptionForPrint}
        clinic={clinic}
        patientPhone={
          prescriptionForPrint
            ? patients.find((p) => p.id === prescriptionForPrint.patientId)?.phone || ''
            : ''
        }
      />

      {/* Invoice Receipt Print Slip Modal */}
      <InvoicePrintModal
        isOpen={!!invoiceForPrint}
        onClose={() => setInvoiceForPrint(null)}
        invoice={invoiceForPrint}
        clinic={clinic}
        patientPhone={
          invoiceForPrint
            ? invoiceForPrint.patientPhone || patients.find((p) => p.id === invoiceForPrint.patientId)?.phone || ''
            : ''
        }
      />

      {/* Change Password Modal */}
      <ChangePasswordModal
        isOpen={isChangePasswordModalOpen}
        onClose={() => setIsChangePasswordModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
